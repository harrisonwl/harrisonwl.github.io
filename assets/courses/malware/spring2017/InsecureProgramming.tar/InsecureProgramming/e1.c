/* specially crafted to feed your brain by gera@core-sdi.com */

/* jumpy vfprintf, Batman!                                   */

int main(int argv,char **argc) {
                      /* Can you do it changing the stack?  */
                      /* Can you do it without changing it? */
	printf(argc[1]);
	while(1);
}
