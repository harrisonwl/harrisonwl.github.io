/* fs5.c                                                    *
 * specially crafted to feed your brain by gera@core-sdi.com */

/* go, go, go!                                              */
int main(int argv,char **argc) {
	char buf[256];
	snprintf(buf,sizeof buf,argc[1]);

                      /* this line'll make your life easier */
//	printf("%s\n",buf);             
}
