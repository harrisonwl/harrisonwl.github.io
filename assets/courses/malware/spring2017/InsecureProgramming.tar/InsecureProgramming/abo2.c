/* abo2.c                                                   * 
 * specially crafted to feed your brain by gera@core-sdi.com */

/* This is a tricky example to make you think               * 
 * and give you some help on the next one                   */

int main(int argv,char **argc) {
	char buf[256];

	strcpy(buf,argc[1]);
	exit(1);
}
