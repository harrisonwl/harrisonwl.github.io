module Stateful where

import Prelude hiding (LT, GT, EQ, id)
import Base
import Data.Maybe
import StateMonadAST
import Operators
import StatefulParse

-- evaluate :: Exp -> Env -> Stateful Value
-- evaluate :: Exp -> Env -> Memory -> (Value,Memory)
evaluate :: Exp -> Env -> SM Value

-- evaluate (Literal v) env m = (v,m)
evaluate (Literal v) env = return v
  -- \ m -> (v,m)

-- evaluate (Unary op a) env m1 =
--   let (av,m2) = evaluate a env m1 in
--   (unary op av, m2)

evaluate (Unary op a) env =
  do
    av <- evaluate a env
    return (unary op av)


evaluate (Binary op a b) env =
  do
    av <- evaluate a env
    bv <- evaluate b env
    return (binary op av bv)


-- evaluate (If a b c) env m1 = 
--   let (BoolV test,m2) = evaluate a env m1 in
--     if test then evaluate b env m2
--             else evaluate c env m2

evaluate (If a b c) env =
  do
    (BoolV test) <- evaluate a env
    if test then evaluate b env
            else evaluate c env

-- evaluate (Declare x exp body) env m1 =
--   let (v,m2) = evaluate exp env m1 in
--   evaluate body ((x, freeze v) : env) m2

evaluate (Declare x exp body) env =
  do
    v <- evaluate exp env
    evaluate body ((x, return v) : env)


evaluate (RecDeclare x exp body) env = evaluate body newEnv
  where newEnv = (x, evaluate exp newEnv) : env

evaluate (Variable x) env         = fromJust (lookup x env)


evaluate (Function x body) env     = return (ClosureV x body env)


-- evaluate (Call fun arg) env m1 =
--   let (ClosureV x body closeEnv,m2) = evaluate fun env m1 in
--   let (v,m3)                        = evaluate arg env m2 in
--   let newEnv                        = (x, freeze v) : closeEnv in
--   evaluate body newEnv m3

evaluate (Call fun arg) env =
  do
    (ClosureV x body closeEnv) <- evaluate fun env
    v                          <- evaluate arg env
    let newEnv = (x, return v) : closeEnv
    evaluate body newEnv

evaluate (Seq e1 e2) env =
  do
    evaluate e1 env
    evaluate e2 env

-- evaluate (Access e) env m1 =
--   let (AddressV a,m2) = evaluate e env m1 in
--   (access a m2,m2)

evaluate (Access e) env =
  do
    (AddressV a) <- evaluate e env
    m            <- get
    return (access a m)

-- evaluate (Assign e1 e2) env m1 = 
--   let (AddressV a,m2) = evaluate e1 env m1 in
--   let (ev,m3)         = evaluate e2 env m2 in
--   (ev, update a ev m3)

evaluate (Assign e1 e2) env =
  do
    (AddressV a) <- evaluate e1 env
    ev           <- evaluate e2 env
    upd (update a ev)
    return ev
    

-- evaluate (Mutable e) env m1 =
--   let (v,m2) = evaluate e env m1 in
--   (AddressV (length m2), m2 ++ [v])

evaluate (Mutable e) env =
  do
    v <- evaluate e env
    m <- get
    upd (\ m -> m ++ [v])
    return (AddressV (length m))

execute exp = deSM (evaluate exp []) []



unary Not (BoolV b) = BoolV (not b)
unary Neg (IntV i)  = IntV (-i)

binary Add (IntV a)  (IntV b)  = IntV (a + b)
binary Sub (IntV a)  (IntV b)  = IntV (a - b)
binary Mul (IntV a)  (IntV b)  = IntV (a * b)
binary Div (IntV a)  (IntV b)  = IntV (a `div` b)
binary And (BoolV a) (BoolV b) = BoolV (a && b)
binary Or  (BoolV a) (BoolV b) = BoolV (a || b)
binary LT  (IntV a)  (IntV b)  = BoolV (a < b)
binary LE  (IntV a)  (IntV b)  = BoolV (a <= b)
binary GE  (IntV a)  (IntV b)  = BoolV (a >= b)
binary GT  (IntV a)  (IntV b)  = BoolV (a > b)
binary EQ  a         b         = BoolV (a == b)
binary op  a         b         = error ("Invalid binary " ++ show op ++ " operation") 
