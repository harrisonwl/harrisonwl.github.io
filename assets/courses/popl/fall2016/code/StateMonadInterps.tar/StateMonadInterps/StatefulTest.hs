import Base
import StatefulAST
import Stateful
import StatefulParse

-- should work the same
facrec = parseExp ("rec fac = function(n) { if (n==0) { 1 } else { n * fac(n-1) } };" ++
                   "fac(5)")

t0 = parseExp ("var x = mutable 3;" ++
               "x = @x + 1;"        ++
               "@x")

t1 = parseExp ("var x = mutable 3;"++
               "var y = mutable true;"++
               "if (@y) { x = @x + 1 } else { x };"++
               "@x")

t2 = parseExp ("var x = mutable 3;"++
               "var y = mutable 7;"++
               "x = @x + @y;"++
               "@x * @y")
