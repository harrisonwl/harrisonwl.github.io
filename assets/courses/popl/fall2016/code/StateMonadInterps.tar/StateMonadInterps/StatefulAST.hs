module StatefulAST where

import Prelude hiding (LT, GT, EQ)
import Operators

data Exp = Literal    Value
         | Unary      UnaryOp Exp
         | Binary     BinaryOp Exp Exp
         | If         Exp Exp Exp
         | Variable   String
         | Declare    String Exp Exp
         | RecDeclare String Exp Exp
         | Function   String Exp     
         | Call       Exp Exp        
         | Seq       Exp Exp     -- new
         | Mutable   Exp         -- new
         | Access    Exp         -- new
         | Assign    Exp Exp     -- new
    deriving (Show,Eq)
             
data Value = IntV  Int
           | BoolV Bool
           | ClosureV String Exp Env
           | AddressV Int        -- new

instance Eq Value where
  IntV i == IntV j         = i==j
  BoolV b == BoolV c       = b==c
  AddressV i == AddressV j = i==j
  _ == _                   = False

instance Show Value where
  show (IntV i)         = show i
  show (BoolV b)        = show b
  show (ClosureV x e r) = "\\ " ++ x ++ " -> " ++ show e
  show (AddressV i)     = show i

type Env    = [(String, Stateful Value)]
type Memory = [Value]

access i mem = mem !! i

update :: Int -> Value -> Memory -> Memory
update addr val mem =
  let (before, _ : after) = splitAt addr mem in
    before ++ [val] ++ after

type Stateful t = Memory -> (t, Memory)
