module Stateful where

import Prelude hiding (LT, GT, EQ, id)
import Base
import Data.Maybe
import StatefulAST
import Operators
import StatefulParse
-- should work the same
facrec = parseExp ("rec fac = function(n) { if (n==0) { 1 } else { n * fac(n-1) } };" ++
                   "fac(5)")

t0 = parseExp ("var x = mutable 3;" ++
               "x = @x + 1;"        ++
               "@x")

t1 = parseExp ("var x = mutable 3;"++
               "var y = mutable true;"++
               "if (@y) { x = @x + 1 } else { x };"++
               "@x")

t2 = parseExp ("var x = mutable 3;"++
               "var y = mutable 7;"++
               "x = @x + @y;"++
               "@x * @y")

-- type Stateful t = Memory -> (t, Memory)
-- evaluate :: Exp -> Env -> Value

freeze :: a -> Memory -> (a,Memory)
freeze v = \ m -> (v,m)

evaluate :: Exp -> Env -> Memory -> (Value,Memory)

evaluate (Literal v) env m = (v,m)

evaluate (Unary op a) env m1 =
  let (av,m2) = evaluate a env m1 in
  (unary op av, m2)

evaluate (Binary op a b) env m1 =
  let (av,m2) = evaluate a env m1 in
  let (bv,m3) = evaluate b env m2 in
  (binary op av bv,m3)

evaluate (If a b c) env m1 = 
  let (BoolV test,m2) = evaluate a env m1 in
    if test then evaluate b env m2
            else evaluate c env m2

evaluate (Declare x exp body) env m1 =
  let (v,m2) = evaluate exp env m1 in
  evaluate body ((x, freeze v) : env) m2

evaluate (RecDeclare x exp body) env m = evaluate body newEnv m
  where newEnv = (x, evaluate exp newEnv) : env

evaluate (Variable x) env m         = fromJust (lookup x env) m

evaluate (Function x body) env m    = (ClosureV x body env,m)

evaluate (Call fun arg) env m1 =
  let (ClosureV x body closeEnv,m2) = evaluate fun env m1 in
  let (v,m3)                        = evaluate arg env m2 in
  let newEnv                        = (x, freeze v) : closeEnv in
  evaluate body newEnv m3

evaluate (Seq e1 e2) env m1    =
  let (_,m2) = evaluate e1 env m1 in
  evaluate e2 env m2

evaluate (Mutable e) env m1    =
  let (ev,m2) = evaluate e env m1 in
  (AddressV (length m2), m2 ++ [ev])

evaluate (Access e) env m1     =
  let (AddressV a,m2) = evaluate e env m1 in
  (access a m2,m2)

evaluate (Assign e1 e2) env m1 =
  let (AddressV a,m2) = evaluate e1 env m1 in
  let (ev,m3)         = evaluate e2 env m2 in
  (ev,update a ev m3)
  
execute exp = evaluate exp [] []

unary Not (BoolV b) = BoolV (not b)
unary Neg (IntV i)  = IntV (-i)

binary Add (IntV a)  (IntV b)  = IntV (a + b)
binary Sub (IntV a)  (IntV b)  = IntV (a - b)
binary Mul (IntV a)  (IntV b)  = IntV (a * b)
binary Div (IntV a)  (IntV b)  = IntV (a `div` b)
binary And (BoolV a) (BoolV b) = BoolV (a && b)
binary Or  (BoolV a) (BoolV b) = BoolV (a || b)
binary LT  (IntV a)  (IntV b)  = BoolV (a < b)
binary LE  (IntV a)  (IntV b)  = BoolV (a <= b)
binary GE  (IntV a)  (IntV b)  = BoolV (a >= b)
binary GT  (IntV a)  (IntV b)  = BoolV (a > b)
binary EQ  a         b         = BoolV (a == b)
binary op  a         b         = error ("Invalid binary " ++ show op ++ " operation") 
