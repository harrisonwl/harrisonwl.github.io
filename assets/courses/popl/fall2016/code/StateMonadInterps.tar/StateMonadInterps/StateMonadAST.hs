module StateMonadAST where

import Prelude hiding (LT, GT, EQ)
import Operators

---
--- Starting with GHC 7.10, you need to add these incantations when
--- you define a monad. Just ignore it for now, it's unimportant.
---
import Control.Applicative (Applicative(..))
import Control.Monad       (liftM, ap)
instance Functor SM where
    fmap = liftM
instance Applicative SM where
    pure  = return
    (<*>) = ap
instance Functor Checked where
    fmap = liftM
instance Applicative Checked where
    pure  = Good
    (<*>) = ap
---
---    

data Exp = Literal    Value
         | Unary      UnaryOp Exp
         | Binary     BinaryOp Exp Exp
         | If         Exp Exp Exp
         | Variable   String
         | Declare    String Exp Exp
         | RecDeclare String Exp Exp
         | Function   String Exp     
         | Call       Exp Exp        
         | Seq       Exp Exp     -- new
         | Mutable   Exp         -- new
         | Access    Exp         -- new
         | Assign    Exp Exp     -- new
    deriving (Show,Eq)
             
data Value = IntV  Int
           | BoolV Bool
           | ClosureV String Exp Env
           | AddressV Int        -- new

instance Eq Value where
  IntV i == IntV j         = i==j
  BoolV b == BoolV c       = b==c
  AddressV i == AddressV j = i==j
  _ == _                   = False

instance Show Value where
  show (IntV i)         = show i
  show (BoolV b)        = show b
  show (ClosureV x e r) = "\\ " ++ x ++ " -> " ++ show e
  show (AddressV i)     = show i

type Env    = [(String, SM Value)]
type Memory = [Value]

access i mem = mem !! i

update :: Int -> Value -> Memory -> Memory
update addr val mem =
  let (before, _ : after) = splitAt addr mem in
    before ++ [val] ++ after

freeze :: a -> Memory -> (a,Memory)
freeze v = \ m -> (v,m)

data SM a = SM (Memory -> (a,Memory))
deSM (SM x) = x

-- return :: a -> SM a
-- (>>=) :: SM a -> (a -> SM b) -> SM b

instance Monad SM where
  return v     = SM (freeze v)
  (SM x) >>= f = SM (\ m -> let (v,m') = x m in deSM (f v) m')

get :: SM Memory
get = SM (\ m -> (m, m))

upd :: (Memory -> Memory) -> SM ()
upd f = SM (\ m -> ((),f m))


data Checked a = Good a | Error String
  deriving (Show,Eq)

raise :: String -> Checked a
raise msg = Error msg

catch :: Checked a -> Checked a -> Checked a
catch e1 e2 = case e1 of
  Good a  -> Good a
  Error _ -> e2

-- return :: a -> Checked a
-- (>>=) :: Checked a -> (a -> Checked b) -> Checked b

instance Monad Checked where
  return v = pure v
  a >>= f =
    case a of
      Error msg -> Error msg
      Good v    -> f v

