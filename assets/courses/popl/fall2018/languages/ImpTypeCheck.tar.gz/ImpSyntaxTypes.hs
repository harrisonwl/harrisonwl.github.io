module ImpSyntaxTypes where

--
-- Abstract syntax for the "Imp" language.
--

-- names (variables) are just strings.
type Name = String

-- a program is a series (list) of variable declarations and a series (list)
-- of statements.
type Prog = (TypeEnv,[Stmt])

-- a variable declaration is a type and a variable name
type TypeEnv = [(Name,Type)]

-- a type is either "int" or "bool", or "int[]..[]" or "bool[]..[]"
data Type = BaseType BT | ArrayType BT Int deriving (Eq,Show)
data BT   = TyInt | TyBool deriving (Show,Eq)

-- statements
data Stmt =
    Assign Name Exp                -- name := exp;
  | ArrayAssign Name [Exp] Exp     -- name [ exp ] .. [ exp ] := exp;
  | If Exp [Stmt] [Stmt]           -- if bexp { stmt* } else { stmt* }
  | While Exp [Stmt]               -- while bexp { stmt* }
  | Let Name Exp [Stmt]            -- let name=exp in { stmt* }
  | LetArray Name [Exp] Exp [Stmt] -- letarray name [ exp ] .. [ exp ] := exp in { stmt* }
  | Switch Exp [(Int,[Stmt])]      -- switch statements
  | For Name Exp Exp [Stmt]        -- for-loop
  deriving Show

--
-- N.b., Exp has both integer and boolean expressions.
--
data Exp =
    Add Exp Exp     
  | Sub Exp Exp     
  | Mul Exp Exp     
  | Neg Exp         
  | LitInt Int         
  | Var Name        
  | VarArray Name [Exp] -- (name [ exp ])
  | IsEq Exp Exp        -- (exp == exp)
  | IsNEq Exp Exp       -- (exp != exp)
  | IsGT Exp Exp        -- (exp > exp)
  | IsLT Exp Exp        -- (exp < exp)
  | IsGTE Exp Exp       -- (exp >= exp)
  | IsLTE Exp Exp       -- (exp = exp)
  | And Exp Exp         -- (bexp && bexp)
  | Or Exp Exp          -- (bexp || bexp)
  | Not Exp             -- (!bexp)
  | LitBool Bool        -- (true or false)
  deriving Show
