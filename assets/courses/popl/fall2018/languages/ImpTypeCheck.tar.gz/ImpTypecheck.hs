module Typecheck where

import ImpSyntaxTypes

--The main function
checkProg :: Prog -> Bool
checkProg (tenv, p)                 = checkStmts tenv p

-- Checks if a statement list is well-typed (i.e., each statement is well-typed).
checkStmts :: TypeEnv -> [Stmt] -> Bool
checkStmts tenv []                  = True
checkStmts tenv (stmt:stmtlist)     = checkStmt tenv stmt && checkStmts tenv stmtlist
--checkStmts tenv = foldr (\ s stmts -> checkStmt tenv s && stmts) True

-- Checks if statement is well-typed
checkStmt :: TypeEnv -> Stmt -> Bool
checkStmt tenv (Assign x e) | isInt x tenv  = checkExp tenv e TyInt
                            | isBool x tenv = checkExp tenv e TyBool
                            | otherwise     = error "possible?"
checkStmt tenv (ArrayAssign x is e) = isIntExpLst tenv is &&
                                      ((checkExp tenv e TyInt && isIntArr x tenv) || 
                                         (checkExp tenv e TyBool && isBoolArr x tenv))
checkStmt tenv (If e p1 p2)         = undefined -- ensure the guard is Boolean
checkStmt tenv (While e p)          = checkExp tenv e TyBool &&
                                      checkStmts tenv p
checkStmt tenv (Let x e p)          = (checkExp tenv e TyInt &&
                                         checkStmts ((x,BaseType TyInt):tenv) p) ||
                                      (checkExp tenv e TyBool &&
                                         checkStmts ((x,BaseType TyBool):tenv) p)
checkStmt tenv (LetArray x xs e p)  = undefined -- ensure indices are integers

-- Checks if a variable has integer type in the type environment
isInt :: Name -> TypeEnv -> Bool
isInt x tenv = case lookup x tenv of
  Just t | t == (BaseType TyInt) -> True
         | otherwise             -> False
  Nothing                        -> False

-- Checks if a variable has type Boolean in the type environment
isBool :: Name -> TypeEnv -> Bool
isBool x tenv = case lookup x tenv of
  Just t | t == BaseType TyBool -> True
         | otherwise            -> False
  Nothing                       -> False

-- Checks if a variable has type Int array in the type environment.
-- The second argument is the the dimension of the array.
isIntArr :: Name -> TypeEnv -> Bool 
isIntArr x tenv = case lookup x tenv of
  Just (ArrayType TyInt _) -> True
  _                        -> False


-- Checks if a variable has type Bool array in the type environment.
isBoolArr :: Name -> TypeEnv -> Bool 
isBoolArr x tenv = case lookup x tenv of
  Just (ArrayType TyBool _) -> True
  _                         -> False

-- Checks that all items list are of integer type
isIntExpLst :: TypeEnv -> [Exp] -> Bool
--isIntExpLst tenv es = map
isIntExpLst tenv []     = True 
isIntExpLst tenv (e:es) = if checkExp tenv e TyInt
                             then isIntExpLst tenv es
                             else False


-- Given a type environment, an expression e and a base type bt checks if the expression has type e
checkExp :: TypeEnv -> Exp -> BT -> Bool
checkExp tenv (Var x) TyInt          = isInt x tenv
checkExp tenv (Var x) TyBool         = isBool x tenv
checkExp tenv (VarArray x xs) TyInt  = undefined
checkExp tenv (VarArray x xs) TyBool = undefined
-- can only be int-exp 
checkExp tenv (Add e1 e2) TyInt      = checkExp tenv e1 TyInt && checkExp tenv e2 TyInt
checkExp tenv (Mul e1 e2) TyInt      = checkExp tenv e1 TyInt && checkExp tenv e2 TyInt
checkExp tenv (Sub e1 e2) TyInt      = checkExp tenv e1 TyInt && checkExp tenv e2 TyInt
checkExp tenv (Neg e) TyInt          = checkExp tenv e TyInt
checkExp _ (LitInt _) TyInt          = True
-- can only be bool-exp
checkExp tenv (IsEq e1 e2) TyBool    = (checkExp tenv e1 TyInt && checkExp tenv e2 TyInt) ||
                                       (checkExp tenv e1 TyBool && checkExp tenv e2 TyBool)
checkExp tenv (IsNEq e1 e2) TyBool   = (checkExp tenv e1 TyInt && checkExp tenv e2 TyInt) ||
                                       (checkExp tenv e1 TyBool && checkExp tenv e2 TyBool)
checkExp tenv (IsLT e1 e2) TyBool    = (checkExp tenv e1 TyInt && checkExp tenv e2 TyInt)
checkExp tenv (IsGT e1 e2) TyBool    = undefined
checkExp tenv (IsGTE e1 e2) TyBool   = undefined
checkExp tenv (IsLTE e1 e2) TyBool   = undefined
checkExp tenv (And b1 b2) TyBool     = undefined
checkExp tenv (Or b1 b2) TyBool      = undefined
checkExp tenv (Not b) TyBool         = checkExp tenv b TyBool
checkExp _ (LitBool _) TyBool        = True
checkExp _ _ _                       = False     -- Everything else has to be ill-typed


