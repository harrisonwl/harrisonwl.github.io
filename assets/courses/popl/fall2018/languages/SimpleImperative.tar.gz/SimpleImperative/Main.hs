module Main where

import WhileAS
import While 
import Text.ParserCombinators.Parsec
import Text.ParserCombinators.Parsec.Expr
import qualified Text.ParserCombinators.Parsec.Token as P
import Text.ParserCombinators.Parsec.Language( javaStyle )

newfib = "newfib.wh"
fib    = "fib.wh"
fac    = "fac.wh"
err    = "errfac.wh"

front fname
  = do{ input <- readFile fname
      ; putStr input
      ; case parse program fname input of
           Left err -> error (show err)
           Right x  -> return x
      }

run fname = do
  c <- front fname
  return (exec c mem0)
    where
      mem0 :: Memory
      mem0 = [("x",5),("y",0),("z",0)]

type Memory = [(Ident, Int)]
type Trans = (Stat, Memory) -> Memory

--
-- memory look-up
--
lkup :: Memory -> Ident -> Int
lkup ((x, n):ms) x' = if x == x' then n else lkup ms x'
lkup [ ] x'         = error ("Unbound variable: " ++ x')

--
-- evaluate an arithmetic expression:
--
evE (Var i) m        = lkup m i
evE (IntLit i) m     = i
evE (AOp op e1 e2) m = case op of
                         "+" -> evE e1 m + evE e2 m
                         "*" -> evE e1 m * evE e2 m
                         "-" -> evE e1 m - evE e2 m
                         _   -> error ("Undefined operator: " ++ op)
                            
evB (BUnOp "not" b) m    = not (evB b m)
evB (BoolLit b) m        = b
evB (BOp "&" b1 b2) m    = evB b1 m && evB b2 m
evB (RelOp ">" e1 e2) m  = evE e1 m > evE e2 m
evB (RelOp "<=" e1 e2) m = evE e1 m <= evE e2 m

exec :: Stat -> Memory -> Memory
exec (Skip _) m       = m
exec (Assign i e _) m = (i,evE e m) : m
exec (Seq [c1,c2]) m  = exec c2 (exec c1 m)
exec (Seq cs) m       = (foldr (\ f g -> g . f) id (map exec cs)) m
exec (If b _ s1 s2) m = if evB b m
                           then
                              exec s1 m
                           else
                              exec s2 m
exec (While b l c) m  = if evB b m 
                           then
                              exec (Seq [c,While b l c]) m
                           else
                              m
exec (NewInt x c) m   = error "NewInt exec undefined"
