module Parser_SimpleTypes where

import AST_SimpleTypes
import Parsing

parseNumber, parseBoolean, parseArrow, parseTy :: Parser Ty

parseNumber  = do
  symbol "Number"
  return Number

parseBoolean = do
  symbol "Boolean"
  return Boolean

parseArrow = do
  symbol "("
  t1 <- parseTy
  symbol "->"
  t2 <- parseTy
  symbol ")"
  return (Arrow t1 t2)

parseTy = parseBoolean +++ parseNumber +++ parseArrow

parseDecl :: Parser (String,Ty)
parseDecl = do
  x <- identifier
  symbol "::"
  t <- parseTy
  return (x,t)
  
--
-- This is the thing we're trying to define.
--
parser :: String -> [(String,Ty)]
parser inp = case parse (many1 parseDecl) inp of
                  [(e,_)] -> e
                  _       -> error "syntax error"
