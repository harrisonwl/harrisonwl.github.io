module AST_SimpleTypes where

data Ty = Number | Boolean | Arrow Ty Ty deriving Show
