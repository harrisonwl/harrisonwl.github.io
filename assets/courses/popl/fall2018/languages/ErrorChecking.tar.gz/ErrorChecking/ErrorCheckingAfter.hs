module ErrorCheckingAfter where

import Prelude hiding (LT, GT, EQ, id)
import RecursiveFunctionsAST 
import Operators

---
--- Starting with GHC 7.10, you need to add these incantations when
--- you define a monad. Just ignore it for now, it's unimportant.
---
import Control.Applicative (Applicative(..))
import Control.Monad       (liftM, ap)
instance Functor Checked where
    fmap = liftM
instance Applicative Checked where
    pure  = Good
    (<*>) = ap
---
---    

instance Monad Checked where
  return v = pure v
  a >>= f =
    case a of
      Error msg -> Error msg
      Good v    -> f v

evaluate :: Exp -> Env -> Checked Value

evaluate (Literal v) env = return v

evaluate (Variable x) env =
  case lookup x env of
    Nothing -> Error ("Variable " ++ x ++ " undefined")
    Just xb -> xb

evaluate (Unary op a) env =
  do av <- evaluate a env
     return (unary op av)

evaluate (Binary op a b) env =
  do av <- evaluate a env
     bv <- evaluate b env
     checked_binary op av bv

evaluate (If a b c) env = 
  do av <- evaluate a env
     case av of 
          BoolV test -> if test then evaluate b env else evaluate c env
          _          -> Error ("\nType of " ++ show a ++ " is not Bool")

evaluate (Function x body) env = return (ClosureV x body env)

evaluate (Declare [(x,exp)] body) env = evaluate body newEnv
    where newEnv = (x, evaluate exp env) : env

evaluate (RecDeclare x exp body) env = evaluate body newEnv
  where newEnv = (x, evaluate exp newEnv) : env

evaluate (Call fun arg) env = 
  do f <- evaluate fun env
     case f of
          ClosureV x body closeEnv -> evaluate body newEnv
              where newEnv = ((x, evaluate arg env) : closeEnv)
          _                        -> Error "type error"

checked_unary :: UnaryOp -> Value -> Checked Value
checked_unary Not (BoolV b) = Good (BoolV (not b))
checked_unary Neg (IntV i)  = Good (IntV (-i))
checked_unary op   v         = 
    Error ("Unary " ++ show op ++ " called with invalid argument " ++ show v)

checked_binary :: BinaryOp -> Value -> Value -> Checked Value
checked_binary Add (IntV a)  (IntV b)  = Good (IntV (a + b))
checked_binary Sub (IntV a)  (IntV b)  = Good (IntV (a - b))
checked_binary Mul (IntV a)  (IntV b)  = Good (IntV (a * b))
checked_binary Div _         (IntV 0)  = Error "Divide by zero"
checked_binary Div (IntV a)  (IntV b)  = Good (IntV (a `div` b))
checked_binary And (BoolV a) (BoolV b) = Good (BoolV (a && b))
checked_binary Or  (BoolV a) (BoolV b) = Good (BoolV (a || b))
checked_binary LT  (IntV a)  (IntV b)  = Good (BoolV (a < b))
checked_binary LE  (IntV a)  (IntV b)  = Good (BoolV (a <= b))
checked_binary GE  (IntV a)  (IntV b)  = Good (BoolV (a >= b))
checked_binary GT  (IntV a)  (IntV b)  = Good (BoolV (a > b))
checked_binary EQ  a         b         = Good (BoolV (a == b))
checked_binary op  a         b         = 
    Error ("Binary " ++ show op ++ 
           " called with invalid arguments " ++ show a ++ ", " ++ show b)


{-

evaluate :: Exp -> Env -> Checked Value

evaluate (Literal v) env = return v

evaluate (Variable x) env =
  case lookup x env of
    Nothing -> Error ("Variable " ++ x ++ " undefined")
    Just xv -> xv

evaluate (Unary op a) env =
   do av <- evaluate a env
      checked_unary op av

evaluate (Binary op a b) env =
   do av <- evaluate a env
      bv <- evaluate b env
      checked_binary op av bv

{-
evaluate (If a b c) env = 
  let BoolV test = evaluate a env in
    if test then evaluate b env
            else evaluate c env
-}

evaluate (If a b c) env = 
  do av <- evaluate a env
     case av of
          BoolV test -> if test then evaluate b env else evaluate c env
          _          -> Error ("Type of " ++ show a ++ " is not Bool")

evaluate (Function x body) env = return (ClosureV x body env)


evaluate (Declare [(x,exp)] body) env =
  do v <- evaluate exp env
     let newEnv = (x, v) : env
     evaluate body newEnv

evaluate (RecDeclare x exp body) env = evaluate body newEnv
  where Good newEnv = case evaluate exp newEnv of
                           Good v    -> Good ((x, v) : env)
                           Error msg -> Error msg

evaluate (Call fun arg) env =
  do (ClosureV x body closeEnv) <- evaluate fun env
     v                          <- evaluate arg env
     let newEnv = ((x, v) : closeEnv)
     evaluate body newEnv

execute exp = evaluate exp []
-}
