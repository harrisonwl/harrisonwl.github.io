module Main where

import ImpSyntax
import ImpParser
import ThreeAddrSyntax
import ThreeAddrParser
import CodeGen
import System.Environment

-- Defined for you in ImpParser.hs
-- parseProg :: String -> Prog

-- Defined for you in CodeGen.hs
-- compileImp :: Prog -> StateT Label (StateT VirtualReg Identity) ThreeAddrProg

codegen :: FilePath -> IO ()
codegen imp = do
  impprog <- parseImp imp
  putStrLn $ show $ runM $ compileImp impprog
