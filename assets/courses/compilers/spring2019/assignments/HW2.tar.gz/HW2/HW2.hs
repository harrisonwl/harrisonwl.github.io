module HW2 where

import ThreeAddrSyntax


{-
2 Questions/ 50 points each.

Due Thursday, February 28th by 11:59pm.

General Requirements.
---------------------
1. Your solutions to these questions are to be included in this file only.
2. Turn in your homework on blackboard only. Emailing your answers to me or 
   the TAs or turning in a print out in class is the same as not turning it
   in.
3. IMPORTANT: your homework must load into ghci without errors to receive
   any credit. That is, if what you turn in does not load into ghci
   then you will receive a zero for this assignment. No exceptions.
4. If you don't finish a problem and have something that you'd like to have
   considered as partial credit, put it within a comment. This isn't a 
   guarantee that you'll get partial credit, though.
5. Type declarations must be included with every definition you give.

Turning In Your Solution.
-------------------------
To turn in your solution, please email me the code (harrisonwl@missouri.edu)
with the subject "CS4430 HW2". It is important that you get this small detail
right because otherwise I may miss your submitted solution. Your solution
should be in the form of a single Haskell file named "Last-name_HW2.hs".
So, if I did this homework, I’d turn in "Harrison_HW2.hs".

-}

-- ***********************************
--
-- For definitions, wikipedia is just fine:
--     https://en.wikipedia.org/wiki/Basic_block
-- Collberg's slides on this are fine, too:
--     https://www2.cs.arizona.edu/~collberg/Teaching/453/2009/Handouts/Handout-15.pdf
-- Or, check out the StaticProgramAnalysis slides.

-- ***********************************
-- Calculating Basic Blocks.
--     There are two kinds of ThreeAddr instructions: "control-flow" and "regular"


-- ***********************************
-- Q: What are the basic blocks in the following example?

-- ***
-- *** Here is the ThreeAddr code for "foobar.imp":
-- ***
-- 0:	mov R0 #99;
-- 	mov Rx R0;
-- 1:	mov R1 #0;
-- 	sub R2 Rx R1;
-- 	brnz R2 #3;
-- 	mov R2 #0;
-- 	jmp #4;
-- 3:	mov R2 #1;
-- 4:	brz R2 #2;
-- 	mov R3 #1;
-- 	sub R4 Rx R3;
-- 	mov Rx R4;
-- 	jmp #1;
-- 2:	exit;

-- ***
-- *** Here's the above code separated into basic blocks:
-- ***
-- 0:	mov R0 #99;
-- 	mov Rx R0;
--
-- 1:	mov R1 #0;
-- 	sub R2 Rx R1;
-- 	brnz R2 #3;
--
-- 	mov R2 #0;
-- 	jmp #4;
--
-- 3:	mov R2 #1;
--
-- 4:	brz R2 #2;
--
-- 	mov R3 #1;
-- 	sub R4 Rx R3;
-- 	mov Rx R4;
-- 	jmp #1;
--
-- 2:	exit;


-- ***********************************
-- Representing ThreeAddr Basic Blocks.

-- For the purposes of this assignment, a basic block will
-- be represented as list of ThreeAddr instructions; i.e.,

type BasicBlock = [ThreeAddr]

-- ***********************************
-- Q: What are the "control-flow" instructions?
-- A: Control-flow instructions are instructions that
--    (possibly) alter the flow of control of a program
--    execution.

-- Define the control-flow instructions of ThreeAddr by
-- defining the following function. 
controlflow :: ThreeAddr -> Bool
controlflow = undefined

-- Both control-flow and label may be necessary for defining blockify below.
label (Label _) = True
label _         = False

-- Here's how the blockify function works.
-- A call (blockify (tc:tcs) bbacc) inspects tc and, based on what
-- kind of instruction it is, either (1) moves it onto the basic block
-- accumulator bbacc or (2) includes it on the final list of basic blocks.
-- A call (blockify [] bbacc) means that all of the instructions have been
-- inspected and so call is finished. 

blockify :: [ThreeAddr] -> [ThreeAddr] -> [BasicBlock]
blockify [] bbacc       = undefined
blockify (tc:tcs) bbacc = undefined
                                                                

-- In Main.hs, we defined the following function to test blockify:

-- bb :: FilePath -> IO [BasicBlock]
-- bb imp = do
--   impprog <- parseImp imp
--   let ThreeAddrProg tac = runM $ compileImp impprog
--   return $ blockify tac []


-- ***
-- *** Here's the output of bb for foobar.imp:
-- ***
-- [[0:,mov R0 #99,mov Rx R0],
--  [1:,mov R1 #0,sub R2 Rx R1,brnz R2 #3],
--  [mov R2 #0,jmp #4],
--  [3:,mov R2 #1],
--  [4:,brz R2 #2],
--  [mov R3 #1,sub R4 Rx R3,mov Rx R4,jmp #1],
--  [2:,exit]]
