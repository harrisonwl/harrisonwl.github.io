module BasicBlocks where

import CodeGen
import Common
import ImpParser
import ThreeAddrSyntax
import Control.Monad.Identity
import Control.Monad.State

controlflow :: ThreeAddr -> Bool
controlflow (Jmp _)    = True
controlflow (BrZ _ _)  = True
controlflow (BrNZ _ _) = True
controlflow (BrGT _ _) = True
controlflow (BrGE _ _) = True
controlflow (Call _)   = True
controlflow Ret        = True
controlflow Exit       = True
controlflow _          = False

label (Label _) = True
label _         = False

blockify :: [ThreeAddr] -> [ThreeAddr] -> [[ThreeAddr]]
blockify [] acc       = []
blockify (tc:tcs) acc | controlflow tc = (reverse $ tc : acc) : blockify tcs []
                      | label tc       = case acc of
                                              [] -> blockify tcs [tc]
                                              _  -> reverse acc : blockify tcs [tc]
                      | otherwise      = blockify tcs (tc : acc)

type T = StateT (Int,Int) Identity

runT :: T a -> a
runT (StateT x) = a
  where
    Identity (a,_) = x (0,0)

enblockT :: [[ThreeAddr]] -> T [Block]
enblockT []           = return []
enblockT (tacb:tacbs) = do
  bl    <- newblocklabel
  ltacb <- helpT tacb
  ltacbs <- enblockT tacbs
  return ((bl,ltacb) : ltacbs)

helpT :: [ThreeAddr] -> T [(Int,ThreeAddr)]
helpT []         = return []
helpT (tac:tacs) = do
  il <- newinstrlabel
  ltacs <- helpT tacs
  return ((il,tac):ltacs)

newinstrlabel :: T Int
newinstrlabel = do
  (bct,ict) <- get
  put (bct,ict+1)
  return ict

newblocklabel :: T Int
newblocklabel = do
  (bct,ict) <- get
  put (bct+1,ict)
  return bct
                                                              
foobar_tac :: [ThreeAddr]
foobar_tac = [
  Label 0,
  Mov (Reg "0") (Literal 99),
  Mov (Reg "x") (Immediate (Reg "0")),
  Label 1,Mov (Reg "1") (Literal 0),
  Sub (Reg "2") (Immediate (Reg "x")) (Immediate (Reg "1")),
  BrNZ (Reg "2") (Literal 3),
  Mov (Reg "2") (Literal 0),
  Jmp (Literal 4),
  Label 3,
  Mov (Reg "2") (Literal 1),
  Label 4,
  BrZ (Reg "2") (Literal 2),
  Mov (Reg "3") (Literal 1),
  Sub (Reg "4") (Immediate (Reg "x")) (Immediate (Reg "3")),
  Mov (Reg "x") (Immediate (Reg "4")),
  Jmp (Literal 1),
  Label 2,
  Exit]

foobar_bbs :: [[ThreeAddr]]
foobar_bbs = [
  [Label 0,
   Mov (Reg "0") (Literal 99),
   Mov (Reg "x") (Immediate (Reg "0"))],
  [Label 1,Mov (Reg "1") (Literal 0),
   Sub (Reg "2") (Immediate (Reg "x")) (Immediate (Reg "1")),
   BrNZ (Reg "2") (Literal 3)],
  [Mov (Reg "2") (Literal 0),
   Jmp (Literal 4)],
  [Label 3,
   Mov (Reg "2") (Literal 1)],
  [Label 4,
   BrZ (Reg "2") (Literal 2)],
  [Mov (Reg "3") (Literal 1),
   Sub (Reg "4") (Immediate (Reg "x")) (Immediate (Reg "3")),
   Mov (Reg "x") (Immediate (Reg "4")),
   Jmp (Literal 1)],
  [Label 2,
   Exit]]

foobar_blocks :: [(Int, [(Int, ThreeAddr)])]
foobar_blocks =
  [(0,[(0,Label 0),
       (1,Mov (Reg "0") (Literal 99)),
       (2,Mov (Reg "x") (Immediate (Reg "0")))]),
   (1,[(3,Label 1),
       (4,Mov (Reg "1") (Literal 0)),
       (5,Sub (Reg "2") (Immediate (Reg "x")) (Immediate (Reg "1"))),
       (6,BrNZ (Reg "2") (Literal 3))]),
   (2,[(7,Mov (Reg "2") (Literal 0)),
       (8,Jmp (Literal 4))]),
   (3,[(9,Label 3),
       (10,Mov (Reg "2") (Literal 1))]),
   (4,[(11,Label 4),
       (12,BrZ (Reg "2") (Literal 2))]),
   (5,[(13,Mov (Reg "3") (Literal 1)),
       (14,Sub (Reg "4") (Immediate (Reg "x")) (Immediate (Reg "3"))),
       (15,Mov (Reg "x") (Immediate (Reg "4"))),
       (16,Jmp (Literal 1))]),
   (6,[(17,Label 2),
       (18,Exit)])]

  
relabelled = [
  (0,Label 0),
  (1,Mov (Reg "0") (Literal 99)),
  (2,Mov (Reg "x") (Immediate (Reg "0"))),
  (3,Label 3),
  (4,Mov (Reg "1") (Literal 0)),
  (5,Sub (Reg "2") (Immediate (Reg "x")) (Immediate (Reg "1"))),
  (6,BrNZ (Reg "2") (Literal 9)),
  (7,Mov (Reg "2") (Literal 0)),
  (8,Jmp (Literal 11)),
  (9,Label 9),
  (10,Mov (Reg "2") (Literal 1)),
  (11,Label 11),
  (12,BrZ (Reg "2") (Literal 17)),
  (13,Mov (Reg "3") (Literal 1)),
  (14,Sub (Reg "4") (Immediate (Reg "x")) (Immediate (Reg "3"))),
  (15,Mov (Reg "x") (Immediate (Reg "4"))),
  (16,Jmp (Literal 3)),
  (17,Label 17),
  (18,Exit)]

             
--
-- Changing block/CFG format to make it amenable to iterative data flow analysis.
--

reformat :: [Block] -> [(Int,ThreeAddr)]
reformat blks = relabel subst noblocknums
  where
    noblocknums = concat $ map snd blks
    relabellist = nodelabel noblocknums
    subst       = gensubst relabellist

gensubst :: [(Int,ThreeAddr)] -> Int -> Int
gensubst []                = id -- \ i -> i -- error $ show i ++ " unbound"
gensubst ((l,Label l'):ts) = tweek l' l (gensubst ts)

tweek x v f = \ a -> if x==a then v else f a

nodelabel lcs = labelcs
  where
    labelcs = filter isLabel lcs
    isLabel (n,Label _) = True
    isLabel _           = False

relabel :: (Int -> Int) -> [(Int,ThreeAddr)] -> [(Int,ThreeAddr)]
relabel subst []          = []
relabel subst ((n,c):ncs) = case c of
  Label m            -> (n,Label $ subst m) : relabel subst ncs
  Jmp (Literal m)    -> (n,Jmp (Literal $ subst m)) : relabel subst ncs
  BrZ r (Literal m)  -> (n, BrZ r (Literal $ subst m)) : relabel subst ncs
  BrNZ r (Literal m) -> (n,BrNZ r (Literal $ subst m)) : relabel subst ncs
  BrGT r (Literal m) -> (n,BrGT r (Literal $ subst m)) : relabel subst ncs
  BrGE r (Literal m) -> (n,BrGE r (Literal $ subst m)) : relabel subst ncs
  Call (Literal m)   -> (n,Call (Literal $ subst m)) : relabel subst ncs
  _                  -> (n,c) : relabel subst ncs
