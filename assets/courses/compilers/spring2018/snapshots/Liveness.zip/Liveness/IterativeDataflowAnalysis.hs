module IterativeDataFlowAnalysis where

import BasicBlocks
import Common
import Control.Monad.Identity
import Control.Monad.State
import Data.List
import Prelude hiding (round)
import ThreeAddrSyntax


type Node   = Int -- Node label, not block label
type RBlock = (Int,ThreeAddr)

-- ****************************
-- Step 1. Attributes
-- ****************************

-- Here are the type we use to define the various attributes
succ :: [(Node,[Node])]
use  :: [(Node,[Register])]
def  :: [(Node,[Register])]
succ = undefined
use  = undefined
def  = undefined
livein, liveout :: [(Node,[Register])]
livein  = undefined
liveout = undefined
nodes :: [Node]    -- set of defined nodes
nodes = undefined

next :: [(Node, t)] -> [Node]
next []        = []
next ((n,_):_) = [n]

lkup :: (Eq a, Show a,Show t) => a -> [(a, t)] -> t
lkup n [] = error $ "lkup failed for " ++ show n
lkup n ((x,v):al) | x==n      = v
                  | otherwise = lkup n al

--
-- calculates the successors of each node.
--
successors :: [RBlock] -> [(Node,[Node])]
successors []                     = []
successors ((n,Jmp arg) : tcs)    = (n,arg2label arg) : successors tcs
successors ((n,Call arg) : tcs)   = (n,arg2label arg) : successors tcs
successors ((n,BrZ _ arg) : tcs)  = (n,arg2label arg ++ next tcs) : successors tcs
successors ((n,BrNZ _ arg) : tcs) = (n,arg2label arg ++ next tcs) : successors tcs
successors ((n,BrGT _ arg) : tcs) = (n,arg2label arg ++ next tcs) : successors tcs
successors ((n,BrGE _ arg) : tcs) = (n,arg2label arg ++ next tcs) : successors tcs
successors ((n,Ret) : tcs)        = (n,[]) : successors tcs
successors ((n,Exit) : tcs)       = (n,[]) : successors tcs
successors ((n,_) : tcs)          = (n,next tcs) : successors tcs

--
-- Calculate the def and use sets for each node.
--

gendefuse :: [RBlock] -> [(Node,[Register],[Register])]
gendefuse []          = []
gendefuse ((n,c):tcs) = (n,cdefs,cuses) : gendefuse tcs
  where
    (cdefs,cuses) = defuse c    

arg2reg (Immediate r) = [r]
arg2reg (Literal _)   = []

arg2label (Immediate r) = []
arg2label (Literal l)   = [l]

defuse :: ThreeAddr -> ([Register],[Register])
defuse tac = case tac of
   Mov rdst arg         -> ([rdst], arg2reg arg)
   Load rdst rsrc       -> ([rdst],[rsrc])
   Store rdst rsrc      -> undefined 
   Add rdst arg1 arg2   -> ([rdst], arg2reg arg1 ++ arg2reg arg2)
   Sub rdst arg1 arg2   -> ([rdst], arg2reg arg1 ++ arg2reg arg2)
   Div rdst arg1 arg2   -> undefined 
   Mul rdst arg1 arg2   -> ([rdst], arg2reg arg1 ++ arg2reg arg2)
   Negate rdst arg      -> undefined 
   Equal rdst arg1 arg2 -> undefined 
   LogNot rdst arg      -> undefined 
   GThan rdst arg1 arg2 -> ([rdst], arg2reg arg1 ++ arg2reg arg2)
   Jmp arg              -> undefined 
   BrZ rtst arg         -> ([],rtst : arg2reg arg)
   BrNZ rtst arg        -> undefined 
   BrGT rtst arg        -> ([], rtst : arg2reg arg)
   BrGE rtst arg        -> undefined 
   Label _              -> ([],[])
   Read rdst            -> undefined 
   Write arg            -> ([],arg2reg arg)
   Call arg             -> undefined 
   Ret                  -> undefined 
   Exit                 -> undefined 

--
-- Initialization Code?
--

type Liveness = [(Node,[Register])]
type LIxLO    = (
                 Liveness, -- live in
                 Liveness  -- live out
                )

type M = StateT LIxLO Identity 

converge :: (Eq a, Monad m) => a -> m a -> m a
converge v round = do
  v' <- round
  if v==v'
     then return v'
     else converge v' round
  
--
-- Accessor functions. These are, more or less, given by construction of M.
--

getlivein :: M Liveness
getlivein = do
  (li,_) <- get
  return li

getliveout :: M Liveness
getliveout = do
  (_,lo) <- get
  return lo

putlivein :: Liveness -> M ()
putlivein li = do
  (_,lo) <- get
  put (li,lo)

putliveout :: Liveness -> M ()
putliveout lo = do
  (li,_) <- get
  put (li,lo)

--
-- Derived operations. These allow us to read and update
-- the "stored" register set at node n.
--

rdnode_li :: Node -> M [Register]
rdnode_li n = do
  li <- getlivein
  return $ lkup n li

rdnode_lo :: Node -> M [Register]
rdnode_lo n = do
  li <- getliveout
  return $ lkup n li

assign :: Eq a => a -> v -> [(a, v)] -> [(a, v)]
assign n v al = (n,v) : al'
  where
    al' = filter (\ (x,_) -> x/=n) al

setnode_li :: Node -> [Register] -> M ()
setnode_li n rs = do
  li <- getlivein
  putlivein $ assign n rs li

setnode_lo :: Node -> [Register] -> M ()
setnode_lo n rs = do
  lo <- getliveout
  putliveout $ assign n rs lo

-- ****************************
-- Step 2. Data Flow Equations
-- ****************************

-- livein[n] = use[n] `union` (liveout[n] \\ def[n])
equation1 :: [(Node, [Register])] -> -- def set
             [(Node, [Register])] -> -- use set
             Node                 -> -- node to be updated
             M ()
equation1 defs uses n = do
  let defn     = lkup n defs
  let usen     = lkup n uses
  liveoutn <- rdnode_lo n
  let rs       = usen `union` (liveoutn \\ defn)
  setnode_li n rs

-- liveout[n] = U (livein[s]) for s \in succ[n]
equation2 :: [(Node, [Node])] ->
             Node             ->
             M ()
equation2 succ n = do
  li <- getlivein
  let succn    = lkup n succ
  let livein s = lkup s li
  let liveoutn = union_indexed livein succn
  setnode_lo n liveoutn

-- should be written as a right fold.
union_indexed :: Eq a => (i -> [a]) -> [i] -> [a]
union_indexed f []     = []
union_indexed f (i:is) = f i `union` union_indexed f is

-- ******************************************
-- Step 3. Solving DFE Iteratively
-- ******************************************

liveness :: [RBlock] -> M LIxLO
liveness rbs = do
  put (livein0,liveout0) -- initialize livein/liveout
  converge (livein0,liveout0) (round defs uses succ nodes)
   where
      succ     = successors rbs
      dus      = gendefuse rbs
      defs     = map (\ (n,d,_) -> (n,d)) dus
      uses     = map (\ (n,_,u) -> (n,u)) dus
      nodes    = map fst rbs
      livein0  = zip nodes (repeat [])
      liveout0 = zip nodes (repeat [])

round :: [(Node, [Register])] -> -- def set
         [(Node, [Register])] -> -- use set
         [(Node, [Node])]     -> -- successor set
         [Node]               -> -- all nodes
         M LIxLO
round ds us scc ns = do
  foreach datafloweqs ns
  get
     where datafloweqs n = do
             equation1 ds us n
             equation2 scc n


foreach :: (Node -> M ()) -> [Node] -> M ()
foreach _ []     = return ()
foreach f (n:ns) = do
  f n
  foreach f ns

-- Could use built-in mapM_ to define foreach:
--
-- mapM_ :: Monad m => (a -> m b) -> [a] -> m ()
--
-- foreach f ns = mapM_ f ns

--
-- Example.
--

slidesexample :: [RBlock]
slidesexample = [
  (0,Mov (Reg "a") (Literal 0)),
  (1,Add (Reg "b") (Immediate (Reg "a")) (Literal 1)),
  (2,Add (Reg "c") (Immediate (Reg "c")) (Immediate (Reg "b"))),
  (3,Mul (Reg "a") (Immediate (Reg "b")) (Literal 2)),
  (4,GThan (Reg "tst") (Immediate (Reg "a")) (Literal 99)),
  (5,BrGT (Reg "tst") (Literal 1)), 
  (6,Write (Immediate (Reg "c")))]

go :: [RBlock] -> LIxLO
go tac = fst (runIdentity (runStateT (liveness tac) ([],[])))

-- Here's the output made pretty.
ex = ([(6,[Reg "c"]),
       (5,[Reg "tst",Reg "a",Reg "c"]),
       (4,[Reg "a",Reg "c"]),
       (3,[Reg "b",Reg "c"]),
       (2,[Reg "c",Reg "b"]),
       (1,[Reg "a",Reg "c"]),
       (0,[Reg "c"])],
       [(6,[]),
        (5,[Reg "a",Reg "c"]),
        (4,[Reg "tst",Reg "a",Reg "c"]),
        (3,[Reg "a",Reg "c"]),
        (2,[Reg "b",Reg "c"]),
        (1,[Reg "c",Reg "b"]),
        (0,[Reg "a",Reg "c"])])
