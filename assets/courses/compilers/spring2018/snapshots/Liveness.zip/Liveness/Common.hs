module Common where

import Prelude hiding (Word)

type Label      = Int
type VirtualReg = Int 
type Word       = Int
data Register   = Reg String | SP | FP | BP deriving (Eq,Show)

data Arg        = Immediate Register | Literal Word deriving Show

-- instance Show Register where
--     show (Reg i) = "R" ++ i
--     show SP      = "SP"
--     show BP      = "BP"
--     show FP      = "FP"

-- instance Show Arg where
--   show (Immediate r) = show r
--   show (Literal w)   = '#' : show w

register :: Register -> Arg
register = Immediate

word :: Word -> Arg
word = Literal

(<>) :: Monad m => (a -> m b) -> (b -> m c) -> a -> m c
f <> g = \ a -> f a >>= g
