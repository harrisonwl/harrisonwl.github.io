module ImpInterpreter where

import ImpSyntax
import ImpParser hiding (expr,stmt)

check :: [Stmts] -> [Name] -> Bool
check [] _        = True
check (c:cs) seen = case c of
  Assign x _ | x `elem` seen -> check cs seen
             | otherwise     -> False
  If be cs1 cs2              -> check cs1 seen && check cs2 seen
  While be cs                -> check cs seen
  Let x e cs                 -> check cs (x:seen)

interp :: FilePath -> IO (Maybe Store)
interp f = do
  cs <- parseImp f
  if check cs [] then return Nothing else return $ stmts cs sto0

type Store = [(Name,Int)]
sto0       = [] -- initial store

replace :: Name -> Int -> Store -> Maybe Store
replace x i []         = Nothing 
replace x i ((y,v):cs) | x == y = return $ (x,i) : cs
                       | x /= y = do
                                     cs' <- replace x i cs
                                     return $ (y,v) : cs'

stmts :: [Stmt] -> Store -> Maybe Store
stmts [] _     = Nothing -- "empty" program
stmts (c:cs) s = do
                    s' <- stmt c s
                    case cs of
                         [] -> return s'
                         _  -> stmts cs s'

stmt :: Stmt -> Store -> Maybe Store
stmt (Assign x e) s    = do
                            i <- expr e s
                            s' <- replace x i s
                            return s'
stmt (If be cs1 cs2) s = do
                            bv <- bexp be s
                            if bv then stmts cs1 s else stmts cs2 s
stmt l@(While be cs) s = do
                            bv <- bexp be s
                            if bv then stmts (cs++[l]) s else return s
stmt (Let x e cs) s    = do
                            i <- expr e s
                            stmts cs ((x,i):s)

expr :: Exp -> Store -> Maybe Int
expr (Plus e1 e2) s = do
                         i1 <- expr e1 s
                         i2 <- expr e2 s
                         return $ i1 + i2
expr (Subt e1 e2) s = do
                         i1 <- expr e1 s
                         i2 <- expr e2 s
                         return $ i1 - i2
expr (Mult e1 e2) s = do
                         i1 <- expr e1 s
                         i2 <- expr e2 s
                         return $ i1 * i2
expr (Negt e) s     = do
                         i <- expr e s
                         return $ - i
expr (Var x) s      = lookup x s
expr (LitInt i) s   = return i

bexp :: BExp -> Store -> Maybe Bool
bexp (IsEq e1 e2) s = do
                         i1 <- expr e1 s
                         i2 <- expr e2 s
                         return $ i1 == i2
bexp (IsNEq e1 e2) s = do
                         i1 <- expr e1 s
                         i2 <- expr e2 s
                         return $ i1 /= i2
bexp (IsGT e1 e2) s = do
                         i1 <- expr e1 s
                         i2 <- expr e2 s
                         return $ i1 > i2
bexp (IsLT e1 e2) s = do
                         i1 <- expr e1 s
                         i2 <- expr e2 s
                         return $ i1 < i2
bexp (IsGTE e1 e2) s = do
                         i1 <- expr e1 s
                         i2 <- expr e2 s
                         return $ i1 >= i2
bexp (IsLTE e1 e2) s = do
                         i1 <- expr e1 s
                         i2 <- expr e2 s
                         return $ i1 <= i2
bexp (And b1 b2) s = do
                         bv1 <- bexp b1 s
                         bv2 <- bexp b2 s
                         return $ bv1 && bv2
bexp (Or b1 b2) s  = do
                         bv1 <- bexp b1 s
                         bv2 <- bexp b2 s
                         return $ bv1 || bv2
bexp (Not b) s      = do
                         tf <- bexp b s
                         return $ not tf
bexp (LitBool bv) s = return bv


