module Main where

import BasicBlocks
import CodeGen
import Common
import Control.Monad.Identity
import Control.Monad.State
import ImpParser
import ImpSyntax
import System.Environment
import ThreeAddrParser
import ThreeAddrSyntax


codegen :: FilePath -> IO ()
codegen imp = do
  impprog <- parseImp imp
  putStrLn $ show $ runM $ compileImp impprog

-- Defined for you in ImpParser.hs
-- parseImp  :: FilePath -> IO Prog
-- parseProg :: String -> Prog

-- Defined for you in CodeGen.hs
-- compileImp :: Prog -> StateT Label (StateT VirtualReg Identity) ThreeAddrProg

imp2threeaddr :: String -> StateT Label (StateT VirtualReg Identity) ThreeAddrProg
imp2threeaddr = (return . parseProg) <> compileImp 

bb :: FilePath -> IO [[ThreeAddr]]
bb imp = do
  impprog <- parseImp imp
  let ThreeAddrProg tac = runM $ compileImp impprog
  return $ blockify tac []
