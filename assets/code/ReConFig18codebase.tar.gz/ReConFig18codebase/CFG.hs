module CFG where

--
-- Building Graphs in Haskell's Data.Graph is flatulent.
--

data Edge a = a :-> a | a :=> (a,a) | Halt a deriving Show

type CFG addr = (addr,[Edge addr])

cfg0 :: CFG Int
cfg0 = (1,excfg)
  where
    excfg = 1 :-> 2     :
            2 :-> 3     :
            3 :-> 4     : 
            4 :-> 5     :
            5 :=> (2,6) :
            Halt 6      : []

cfg1 :: CFG Int
cfg1 = (1,excfg)
  where
    excfg = 1 :-> 2       :
            2 :=> (3,4)   :
            3 :-> 2       :
            4 :=> (5,6)   :
            5 :=> (8,7)   :
            6 :-> 7       :
            7 :-> 11      :
            8 :-> 9       :
            9 :=> (8,10)  :
            10 :=> (5,12) :
            11 :-> 12     :
            Halt 12       : []

-- sanity checks on CFG
nodes_unique (_,edges) = length edges == length (map prj edges)
  where
    prj (a :-> _) = a
    prj (a :=> _) = a
    prj (Halt a)  = a

start_is_node (start,cfg) = start `elem` (nodes cfg [])

total (_,edges) = setequal (nodes edges []) (map prj edges)
  where
    prj (a :-> _) = a
    prj (a :=> _) = a
    prj (Halt a)  = a
    setequal as bs = setminus as bs == setminus bs as
    setminus [] bs     = bs
    setminus (a:as) bs = setminus as (filter (/=a) bs)
  
nodes [] nl        = nl
nodes (edge:es) nl = case edge of
  a :-> a'      -> nodes es (insertnode a (insertnode a' nl))
  a :=> (a1,a2) -> nodes es (insertnode a (insertnode a1 (insertnode a2 nl)))
  Halt a        -> nodes es (insertnode a nl)
  where
    -- unique insert
    insertnode :: Eq a => a -> [a] -> [a]
    insertnode a []                 = [a]
    insertnode a (b:bs) | a==b      = b:bs
                        | otherwise = b : insertnode a bs

next (i,cfg) = lkup i cfg

lkup i (j :-> k : es) | i==k      = Just k
                      | otherwise = lkup i es
lkup i (j :=> (k,m) : es) | i==k      = Just k
                      | otherwise = lkup i es
                      
