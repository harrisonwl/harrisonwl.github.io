module CompilerCFI where

import CFG
import CFI
import Control.Monad.Identity
import Control.Monad.Resumption.Reactive

cfigen :: Show a => String -> CFG a -> IO ()
cfigen wt cfg = do
    writeFile "CFIMON.hs" cfimon
  where
    cfimon = compile wt cl 
    cl     = cfg2cfl cfg
    -- Usage: cfigen "W8" cfg0

compile :: Show a => String -> CFL a -> String
compile addrtyp (Start i cfg) =
      frontmatter
   ++ bittype
   ++ porttype
   ++ mkcfimon addrtyp
   ++ mkbegin i addrtyp
   ++ mkstop addrtyp
   ++ mkalarm addrtyp
   ++ concat (map (sem addrtyp) cfg)

mkdecl k addr = k ++ " :: " ++ devicetype addr ++ "\n"
  where
    devicetype a  = "ReacT (Port "++ a ++") (Maybe Bit) Identity ()"

----
----
----

sem :: Show a => String -> (Kont a,CLA a) -> String
sem addrtyp (ki,Predict a kj) = 
        mkdecl (show ki) addrtyp
     ++ ki_s ++ " = do\n"
     ++ "  pa   <- signal (Just C)\n"
     ++ "  case pa of\n"
     ++ "   PC a' | a'==" ++ show a ++ "     -> " ++ kj_s ++ "\n"
     ++ "         | otherwise -> alarm\n"
     ++ "   DontCare          -> " ++ ki_s ++"\n"
     ++ "   Enable            -> " ++ ki_s ++ "\n"
     ++ "   Reset             -> cfimon\n\n"
        where
          ki_s = show ki
          kj_s = show kj

sem addrtyp (ki,Branch (j,kj) (k,kk)) =
       mkdecl (show ki) addrtyp
    ++ ki_s ++ " = do\n"
    ++ "  pa   <- signal (Just C)\n"
    ++ "  case pa of\n"
    ++ "   PC a' | a'==" ++ show j ++ "     -> " ++ kj_s ++ "\n"
    ++ "         | a'==" ++ show k ++ "     -> " ++ kk_s ++ "\n"
    ++ "         | otherwise -> alarm\n"
    ++ "   DontCare          -> " ++ ki_s ++"\n"
    ++ "   Enable            -> " ++ ki_s ++ "\n"
    ++ "   Reset             -> cfimon\n\n"
       where
         ki_s = show ki
         kj_s = show kj
         kk_s = show kk

sem addrtyp (ki,Stop) =
       mkdecl (show ki) addrtyp
    ++ ki_s ++ " = stop\n\n"
       where
         ki_s = show ki

frontmatter = "module CFIMON where\n\n"
           ++ "import Control.Monad.Identity\n"
           ++ "import Control.Monad.Resumption.Reactive\n\n"

bittype  = "data Bit    = C | S deriving Show\n\n"
porttype = "data Port a = PC a | DontCare | Enable | Reset deriving Show\n\n"

mkcfimon wt =
            mkdecl "cfimon" wt
         ++ "cfimon = do\n"
         ++ "   pa <- signal Nothing\n"
         ++ "   case pa of\n"
         ++ "     Enable -> begin\n"
         ++ "     _      -> cfimon\n\n"

mkbegin i a =
       "begin :: ReacT (Port " ++ a ++ ") (Maybe Bit) Identity ()\n"
    ++ "begin = do\n   pa   <- signal (Just C)\n   case pa of\n     PC a' | a'=="++ show i ++ "     -> " ++ ki ++"\n"
    ++ "           | otherwise -> alarm\n     DontCare          -> begin\n     Enable            -> begin\n     Reset             -> cfimon\n\n"
     where ki = show (Kont i)

mkstop :: String -> String
mkstop a = "stop :: ReacT (Port " ++ a ++ ") (Maybe Bit) Identity ()\n"
        ++ "stop = cfimon\n\n"

mkalarm :: String -> String
mkalarm a = "alarm :: ReacT (Port " ++ a ++ ") (Maybe Bit) Identity ()\n"
       ++ "alarm = do\n"
       ++ "  pa <- signal (Just S)\n"
       ++ "  case pa of\n"
       ++ "    Reset -> cfimon\n"
       ++ "    _     -> alarm\n\n"
