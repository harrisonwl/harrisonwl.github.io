# Examples

In this directory, we have Agda code examples from figures in the paper plus
semantics for four additional example circuits:
  1. Acummulator.agda
  2. Combinatorial.agda
  3. FibCircuit.agda
  4. ShiftRegister.agda

For each of these, we have a corresponding FIRRTL and lowered FIRRTL
implementation in the `firrtl-interpreter` subdirectory. Therefore, we
can compare the result of evaluating each circuit on both the Agda
interpreter and the FIRRTL interpreter.

The inputs we used for each circuit are given in
`firrtl-interpreter/$FILE.input` and the resulting outputs from the
FIRRTL interpreter are in `firrtl-interpreter/$FILE.output`. Assuming
the `frepl.sh` script for invoking the FIRRTL interpreter is
installed, the interpreter output for each
`firrtl-interpreter/$FILE.lo.fir` can be reproduced with the command:
```
$ frepl.sh $FILE.lo.fir < $FILE.input > $FILE.output
```
We can compare the series of successive circuit states in `$FILE.output`
(delimited by lines starting with `CircuitState`) with the streams generated
from interpreting the circuit semantics in Agda.

See the appendix at the end of this file for some details on installing the
FIRRTL interpreter.

Below we compare each FIRRTL circuit in turn. Note that our comparisons begin
after the circuit has been initialized, so the output from the FIRRTL
interpreter often includes a prelude toggling the circuit's `reset` and clearing
any registers.

## Accumulator.agda & Accumulator.lo.fir

The output from evaluating `runaccumulator` in `Accumulator.agda`:
```
"((0 , 00000001) , 00000001 , 00000000)" ∷
"((0 , 00000001) , 00000010 , 00000001)" ∷
"((0 , 00000001) , 00000011 , 00000010)" ∷
"((0 , 00000001) , 00000100 , 00000011)" ∷
"((0 , 00000001) , 00000101 , 00000100)" ∷
"((0 , 00000001) , 00000110 , 00000101)" ∷
"((0 , 00000001) , 00000111 , 00000110)" ∷
"((0 , 00000001) , 00001000 , 00000111)" ∷
"((0 , 00000001) , 00001001 , 00001000)" ∷
"((0 , 00000001) , 00001010 , 00001001)" ∷ []
```
In each row of the above, the second 8-bit value corresponds to the current
value of `io_in` and the third value corresponds to the current value of
`io_out`.

Compare to the output from the FIRRTL interpreter
(from `firrtl-interpreter/Accumulator.output`):
```
CircuitState 3
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 1
Registers      : accumulator= 1

CircuitState 4
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 2
Registers      : accumulator= 2

CircuitState 5
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 3
Registers      : accumulator= 3

CircuitState 6
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 4
Registers      : accumulator= 4

CircuitState 7
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 5
Registers      : accumulator= 5

CircuitState 8
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 6
Registers      : accumulator= 6

CircuitState 9
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 7
Registers      : accumulator= 7

CircuitState 10
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 8
Registers      : accumulator= 8

CircuitState 11
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 9
Registers      : accumulator= 9

CircuitState 12
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 10
Registers      : accumulator= 10
```

## Combinational.agda

The output from evaluating `runcombinational` in `Combinational.agda`:
```
"((0 , 0000000000000000 , 0000000000000000) , tt , 0000000000000000)" ∷
"((0 , 0000000000000001 , 0000000000000010) , tt , 0000000000000011)" ∷
"((0 , 0000000000000010 , 0000000000000010) , tt , 0000000000000100)" ∷
"((0 , 0000000000000010 , 0000000000000011) , tt , 0000000000000101)" ∷
"((0 , 0000000000000100 , 0000000000000100) , tt , 0000000000001000)" ∷
"((0 , 0000000000000100 , 0000000000000101) , tt , 0000000000001001)" ∷
"((0 , 0000000000000110 , 0000000000000111) , tt , 0000000000001101)" ∷
"((0 , 0000000000000111 , 0000000000000111) , tt , 0000000000001110)" ∷
"((0 , 0000000000001000 , 0000000000001001) , tt , 0000000000010001)" ∷ 
"((0 , 0000000000001010 , 0000000000001010) , tt , 0000000000010100)" ∷ []
```
In each row of the above, the second and third values correspond to `io_x` and
`io_y` respectively, and the last value corresponds to `io_z`.

Compare to the output from the FIRRTL interpreter
(from `firrtl-interpreter/Combinational.output`):
```
CircuitState 3
Inputs: clock= 0, io_x= 0, io_y= 0, reset= 0
Outputs: io_z= 0
Registers      : 

CircuitState 4
Inputs: clock= 0, io_x= 1, io_y= 2, reset= 0
Outputs: io_z= 3
Registers      : 

CircuitState 5
Inputs: clock= 0, io_x= 2, io_y= 2, reset= 0
Outputs: io_z= 4
Registers      : 

CircuitState 6
Inputs: clock= 0, io_x= 2, io_y= 3, reset= 0
Outputs: io_z= 5
Registers      : 

CircuitState 7
Inputs: clock= 0, io_x= 4, io_y= 4, reset= 0
Outputs: io_z= 8
Registers      : 

CircuitState 8
Inputs: clock= 0, io_x= 4, io_y= 5, reset= 0
Outputs: io_z= 9
Registers      : 

CircuitState 9
Inputs: clock= 0, io_x= 6, io_y= 7, reset= 0
Outputs: io_z= 13
Registers      : 

CircuitState 10
Inputs: clock= 0, io_x= 7, io_y= 7, reset= 0
Outputs: io_z= 14
Registers      : 

CircuitState 11
Inputs: clock= 0, io_x= 8, io_y= 9, reset= 0
Outputs: io_z= 17
Registers      : 

CircuitState 12
Inputs: clock= 0, io_x= 10, io_y= 10, reset= 0
Outputs: io_z= 20
Registers      : 
```

## FibCircuit.agda

The output from evaluating `doit` in `FibCircuit.agda`:
```
"(0 , 1) , (0000 , 0001) , 0000)" ∷
"(1 , 0) , (0001 , 0001) , 0000)" ∷
"(0 , 0) , (0001 , 0001) , 0001)" ∷
"(1 , 0) , (0001 , 0010) , 0001)" ∷
"(0 , 0) , (0001 , 0010) , 0001)" ∷
"(1 , 0) , (0010 , 0011) , 0001)" ∷
"(0 , 0) , (0010 , 0011) , 0010)" ∷
"(1 , 0) , (0011 , 0101) , 0010)" ∷
"(0 , 0) , (0011 , 0101) , 0011)" ∷
"(1 , 0) , (0101 , 1000) , 0011)" ∷
"(0 , 1) , (0000 , 0001) , 0000)" ∷ []
```
In each row of the above, the first value corresponds to `clk`, the second to
`reset`, the third to `n`, and the fourth to `m`.

Compare to the output from the FIRRTL interpreter
(from `firrtl-interpreter/FibCircuit.output`):
```
CircuitState 2
Inputs: clk= 0, go= 0, reset= 1
Outputs: out= 0
Registers      : m= 1, n= 0

CircuitState 3
Inputs: clk= 1, go= 1, reset= 0
Outputs: out= 1
Registers      : m= 1, n= 1

CircuitState 4
Inputs: clk= 0, go= 1, reset= 0
Outputs: out= 1
Registers      : m= 2, n= 1

CircuitState 5
Inputs: clk= 1, go= 1, reset= 0
Outputs: out= 2
Registers      : m= 3, n= 2

CircuitState 6
Inputs: clk= 0, go= 1, reset= 0
Outputs: out= 3
Registers      : m= 5, n= 3

CircuitState 7
Inputs: clk= 1, go= 1, reset= 0
Outputs: out= 5
Registers      : m= 8, n= 5

CircuitState 8
Inputs: clk= 0, go= 1, reset= 1
Outputs: out= 0
Registers      : m= 1, n= 0
```

## ShiftRegister.agda

The output from evaluating `runshiftreg` in `ShiftRegister.agda`:
```
"((0 , 0) , (0 , 0 , 0 , 0) , 0)" ∷
"((0 , 1) , (1 , 0 , 0 , 0) , 0)" ∷
"((0 , 0) , (0 , 1 , 0 , 0) , 0)" ∷
"((0 , 1) , (1 , 0 , 1 , 0) , 0)" ∷
"((0 , 1) , (1 , 1 , 0 , 1) , 0)" ∷
"((0 , 0) , (0 , 1 , 1 , 0) , 1)" ∷
"((0 , 0) , (0 , 0 , 1 , 1) , 0)" ∷
"((0 , 0) , (0 , 0 , 0 , 1) , 1)" ∷
"((0 , 0) , (0 , 0 , 0 , 0) , 1)" ∷
"((0 , 1) , (1 , 0 , 0 , 0) , 0)" ∷ []
```
In each row of the above, the second value corresponds to `io_in`, the 4-tuple
corresponds to the values of `r0`, `r1`, `r2`, and `r3`, and the last value
corresponds to `io_out`.

Compare to the output from the FIRRTL interpreter
(from `firrtl-interpreter/ShiftRegister.output`):

```
CircuitState 5
Inputs: clock= 0, io_in= 0, reset= 0
Outputs: io_out= 0
Registers      : r0= 0, r1= 0, r2= 0, r3= 0

CircuitState 6
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 0
Registers      : r0= 1, r1= 0, r2= 0, r3= 0

CircuitState 7
Inputs: clock= 0, io_in= 0, reset= 0
Outputs: io_out= 0
Registers      : r0= 0, r1= 1, r2= 0, r3= 0

CircuitState 8
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 0
Registers      : r0= 1, r1= 0, r2= 1, r3= 0

CircuitState 9
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 1
Registers      : r0= 1, r1= 1, r2= 0, r3= 1

CircuitState 10
Inputs: clock= 0, io_in= 0, reset= 0
Outputs: io_out= 0
Registers      : r0= 0, r1= 1, r2= 1, r3= 0

CircuitState 11
Inputs: clock= 0, io_in= 0, reset= 0
Outputs: io_out= 1
Registers      : r0= 0, r1= 0, r2= 1, r3= 1

CircuitState 12
Inputs: clock= 0, io_in= 0, reset= 0
Outputs: io_out= 1
Registers      : r0= 0, r1= 0, r2= 0, r3= 1

CircuitState 13
Inputs: clock= 0, io_in= 0, reset= 0
Outputs: io_out= 0
Registers      : r0= 0, r1= 0, r2= 0, r3= 0

CircuitState 14
Inputs: clock= 0, io_in= 1, reset= 0
Outputs: io_out= 0
Registers      : r0= 1, r1= 0, r2= 0, r3= 0
```

# Appendix

## Getting/building the FIRRTL interpreter

The Chisel project has released an interactive interpreter for the FIRRTL
intermediate language. It can be downloaded from github. The steps for
downloading and building it:
```
$ git clone https://github.com/freechipsproject/firrtl-interpreter
$ cd firrtl-interpreter
$ sbt compile
```

Now to interactively interpret `$FILE.lo.fir`, use the `frepl.sh` script:
```
$ frepl.sh $FILE.lo.fir
```

## Running the FIRRTL interpreter on our circuit examples

Assuming everything is in the firrtl-interpreter directory, for each $FILE.lo.fir:
```
$ ./frepl.sh $FILE.lo.fir < $FILE.input > $FILE.output
```

## Running the Agda interpreter on our circuit examples

From the source root:
```
$ agda code/examples/$FILE.agda
```
