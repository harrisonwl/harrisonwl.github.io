This is the Agda code associated with "A Mechanized Semantic Metalanguage for 
High Level Synthesis".

This was written in Agda 2.6.1 using Agda standard library 1.3.

The directory structure:
   common        : includes some idiomatic Agda, a Stream module, etc.
   devicecalculus: defines the syntax and semantics of Device Calculus including:
                     * MealyMachine.agda: the definitions for Mealy
		     * Semantics.agda: the semantics for Device Calculus.
   examples      : code from examples in the figures, called Figure[2|4].agda
                   as well as some small sanity check tests.
   firrtl        : the main files here are:
                     * Syntax.agda: has implicitly typed rules for Idealized FIRRTL
		     * TransCircuit.agda: Contains the syntax-directed translation
		       into Device calculus. Top-level function there is "trC".

