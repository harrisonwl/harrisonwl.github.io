module Main where

import Control.Monad.Identity
import Control.Monad.State
import Control.Monad.Resumption.Reactive
import Control.Monad.Resumption.Connectors

import ComputerArithmetic hiding ((<+>))
import MemoryModel hiding (debug)
import Microcode
import RW_UNSAFE hiding (debug)
import MonitorStackIntegrity hiding (debug)

import ReWireFigleaf
import Debug.Trace

--debug = trace
debug x y = y

splitW9 :: Port W9 -> (Port W8, Port Bit)
splitW9 (Valid (W9 b7 b6 b5 b4 b3 b2 b1 b0 ib))
     = (Valid (W8 b7 b6 b5 b4 b3 b2 b1 b0), Valid ib)
splitW9 Complete = (Complete,Complete)
splitW9 DontCare = (DontCare,DontCare)

---
--- making it all beautiful. 
---

--------------------------------------------
--               Simulator                --
--------------------------------------------

connect dev out conn = refold out conn dev

simulator proc code = connect
                         (proc <&> (mkinstrmem code <&> mkram))

(<+>) :: (int_out -> ext_inp -> int_inp1) ->
         (int_out -> ext_inp -> int_inp2) ->
         (int_out -> ext_inp -> (int_inp1, int_inp2))
f <+> g = \ int_out ext_inp -> (f int_out ext_inp, g int_out ext_inp)

--------------------------------------------
--         Generic Monitor Pattern        --
--------------------------------------------

monitor :: Monad m =>
           Device (dw, iw) o s1 m                    -> -- proc
           Device (iw, ibit, reset) (alarm, mo) s2 m -> -- monitor
           ((o, mo) -> o')                           -> -- combine
           (i' -> ((dw, iw), ibit))                  -> -- sample
           Device (i', reset) (o', alarm) (s1, s2) m
monitor p m c s = connect
                    (p <&> m)
                    out
                    conn
   where
     out (o,mo)        = (c (o,_ibit mo),_alarm mo)
     conn _ (i',reset)  = ((dw,iw),(iw,ibit,reset))
        where
           ((dw,iw),ibit) = s i'

-- I'm playing with this:
-- expmonitor :: Monad m =>
--            Device i o s1 m                    -> -- proc
--            Device (iw, ibit, reset) (alarm, mo) s2 m -> -- monitor
--            ((o, mo) -> o')                           -> -- combine
--            (i' -> (i, ibit))                  -> -- sample
--            Device (i', reset) (o', alarm) (s1, s2) m
expmonitor :: Monad m =>
              Device i o s1 m                     -> -- proc
              Device (mi, reset) (alarm, mo) s2 m -> -- monitor
              ((o, mo) -> o')                     -> -- combine
              (i' -> (i, mi))                     -> -- sample
              Device (i', reset) (o', alarm) (s1, s2) m
expmonitor p m c s = connect
                    (p <&> m)
                    out
                    conn
   where
     out (o,(alarm,mo)) = (c (o,mo),alarm)          
     conn _ (i',reset)  = (iproc,(imon,reset))
        where
           (iproc,imon) = s i'

-- this is the sample for the expmonitor version of safe
--sample :: InSig W9 i -> ((Port W8, Port i), (Port W8,Port Bit))
sample insigW9 = ((dw,iw),(iw,ibit))
   where
     iw        = _instr insigW9
     din       = _datain insigW9
     (dw,ibit) = splitW9 din

----------------------------------------------------------
--  This is SAFE: Composing the processor and monitor   --
----------------------------------------------------------

-- safe :: Monad m =>
--          ReacT
--            (InSig W9 W8, Bit)
--            (OutSig W8 W9 W8, Bit)
--            (StateT (((W8, W8), InSig W8 W8, OutSig W8 W8 W8), s2) m)
--            ()
safe :: Monad m =>
        Device
           (InSig W9 W8, Bit)
           (OutSig W8 W9 W8, Bit)
           (((W8, W8), InSig W8 W8, OutSig W8 W8 W8), s2)
           m
safe = monitor unsafe stack_integrity combine sample
   where
     combine :: (OutSig a W8 e,Bit) -> OutSig a W9 e
     combine ((i,r,d,e),ibit) = (i,r,joinW9 d ibit,e)

     sample :: InSig W9 i -> ((Port W8, Port i), Port Bit)
     sample insigW9 = ((dw,iw),ibit)
       where
         iw        = _instr insigW9
         din       = _datain insigW9
         (dw,ibit) = splitW9 din

-- This is the gold standard. It works.
safe' :: Monad m =>
        ReacT
           (InSig W9 W8, Bit)
           (OutSig W8 W9 W8, Bit)
           (StateT (((W8, W8), InSig W8 W8, OutSig W8 W8 W8), s2) m)
           ()
safe' = connect (unsafe <&> stack_integrity) safe_out safe_conn

safe_out (outsigW8,outmon) = (outsigW9,_alarm outmon)
  where
    outsigW9 = ( _fetch outsigW8
               , _read outsigW8
               , joinW9 (_write outsigW8) (_ibit outmon)
               , _extern outsigW8)

joinW9 outsigW8 ibit = case outsigW8 of
   Valid (W8 b7 b6 b5 b4 b3 b2 b1 b0) -> Valid (W9 b7 b6 b5 b4 b3 b2 b1 b0 ibit)
   DontCare                           -> DontCare
   Complete                           -> Complete

safe_conn :: t                ->
             (InSig W9 i, t2) ->
             ((Port W8, Port i), (Port i, Port Bit, t2))
safe_conn _ (insigW9,reset) = ((dw,iw),(iw,ibit,reset))
  where
    iw        = _instr insigW9
    (dw,ibit) = splitW9 (_datain insigW9)

-- for safe keeping
-- --safe_conn :: (OutSig a w e, OutMon) -> (InSig W9 W8, Bit) -> (InSig W8 W8, InMon)
-- safe_conn :: (OutSig a w e, (t1, t2)) ->
--              (InSig W9 i, t)          ->
--              ((Port W8, Port i), (Port i, Port Bit, t))
-- safe_conn (outsig,outmon) (insigW9,reset) = (insig,inmon)
--   where
--     iw     = _instr insigW9
--     din    = _datain insigW9
--     insig  = (iosigw8,iw)
--     (iosigw8,iosigbit) = splitW9 din
--     inmon  = (iw,iosigbit,reset)
--     ibit   = _ibit outmon
--     wr_out = _write outsig
                         

    -- outsigW9 = OutSig { _fetch = _fetch outsigW8
    --                   , _read  = _read outsigW8
    --                   , _write = joinW9 (_write outsigW8) (_ibit outmon)
    --                   , _extern = _extern outsigW8
    --                   }
--    insig  = InSig { _datain = iosigw8, _instr = iw }
    -- inmon  = InMon { _iword = iw
    --                , _integ = iosigbit
    --                , _reset = reset
    --                }

--------------------------------------------
--         Unmonitored System             --
--------------------------------------------

mkunsafe :: Monad m =>
            [Instr] ->
            ReacT () (Port W8)
               (StateT (((W8, W8), InSig W8 W8, OutSig W8 W8 W8), (s1, s2)) m)
               ()
mkunsafe code = simulator unsafe code unsafe_out connunsafe

unsafe_out :: (OutSig a w e, (t, t1)) -> Port e
unsafe_out (outfde,(_,_)) = _extern outfde

connunsafe = conn_unsafe_1 <+> (conn_unsafe_2 <+> conn_unsafe_3)

conn_unsafe_1 (_,(miw,iosig)) () = (iosig,miw)
--conn_unsafe_1 (_,(miw,iosig)) () = InSig { _datain = iosig, _instr = miw }

conn_unsafe_2 (outsig,(_,_)) () = _fetch outsig

conn_unsafe_3 (outsig,(_,_)) () = (_read outsig, _write outsig)

--------------------------------------------
--          Monitored System              --
--------------------------------------------

mksafe :: Monad m =>
          [Instr]   ->
          ReacT Bit (Port W8, Bit)
                (StateT ((((W8, W8), InSig W8 W8, OutSig W8 W8 W8), s4), (s1, s2)) m)
                ()
mksafe code = simulator safe code out_safe_sys conn_safe_sys

out_safe_sys :: ((OutSig a w e, t2), (t, t1)) -> (Port e, t2)
out_safe_sys ((outsigW9,alarm),(_,_)) = (_extern outsigW9,alarm)

conn_safe_sys :: ((OutSig a w1 e, t), (Port i, Port w)) ->
                 Bit                                    ->
                 ((InSig w i, Bit), (Port a, (Port a, Port w1)))
conn_safe_sys = conn_safe_sys1 <+> (conn_safe_sys2 <+> conn_safe_sys3)

conn_safe_sys1 :: ((a, b), (Port i, Port w)) -> Bit -> (InSig w i, Bit)
conn_safe_sys1 ((_,_),(instr,indata)) reset = ((indata,instr),reset)
--  = (InSig { _datain = indata, _instr = instr },reset)

conn_safe_sys2 ((outsig,_),(_,_)) _ = _fetch outsig
conn_safe_sys3 ((outsig,_),(_,_)) _ = (_read outsig, _write outsig)

--------
-------- here are the test cases for the paper
--------

doe = unroll (mkunsafe callreturntest) s0
ray = unroll (mkunsafe calljumptest) s0
mee = unroll (mkunsafe fibcode) s0
fah = unroll (mkunsafe badcode) s0

fee = unr (mksafe callreturntest) s0'
fie = unr (mksafe calljumptest) s0'
foe = unr (mksafe fibcode) s0'
fum = unr (mksafe badcode) s0'

testunsafe :: [Instr] -> Int -> [Port W8]
testunsafe code n = map (\ (_,_,z) -> z) $ rundev (mkunsafe code) (take n (repeat ())) s0

testsafe :: [Instr] -> Int -> [(Port W8, Bit)]
testsafe code n   = map (\ (_,_,z) -> z) $ rundev (mksafe code) (take n (repeat C)) s0'

isValid (Valid _) = True
isValid _         = False

fib_safe_ans = filter (Valid . fst) 

--------------------------------------------
--        test harness & cases            --
--------------------------------------------

unr :: (Show t2, Show t3) =>
       ReacT Bit (Port t3, t2) (StateT t1 Identity) t -> t1 -> IO ()
unr (ReacT phi) s = do
  let Identity (r,s') = runStateT phi s
  case r of
   Left _  -> putStrLn "????"
   Right (o,k) -> do
     case o of
       (DontCare,alarm) -> do
         putStr $ show o ++ ","
         unr (k C) s'
       _        -> do
         putStr $ show o ++ ","
         unr (k C) s'

unroll :: (Show a,Show t2) => ReacT () (Port a) (StateT t2 Identity) t1 -> t2 -> IO ()
unroll (ReacT phi) s =   debug ("INTERNAL: " ++ show s) $ do
  let Identity (r,s') = runStateT phi s
  case r of
   Left _  -> putStrLn "????"
   Right (o,k) -> do
     case o of
       DontCare -> do
         putStr $ show o ++ ","
         unroll (k ()) s'
       _        -> do
         putStr $ show o ++ ","
         unroll (k ()) s'

s0 :: (((W8, W8), InSig W8 W8, OutSig W8 W8 W8), (String, String))
s0 = (((W8 C C C C C C C C, W8 C S S C C S C C), insig0, outsig0), ("undef", "und"))
   -- where
   --   insig0  = InSig { _datain = DontCare,
   --                     _instr  = DontCare }
   --   outsig0 = OutSig { _fetch  = DontCare,
   --                      _read   = DontCare,
   --                      _write  = DontCare,
   --                      _extern = DontCare }

--s0' :: (((W8, W8), InSig W8 W8, OutSig W8 W8 W8), (String, String))
s0' = ((((W8 C C C C C C C C, W8 C S S C C S C C), insig0, outsig0), "undef"),("undef", "und"))

insig0  = (DontCare,DontCare)
outsig0 = (DontCare,DontCare,DontCare,DontCare)
     -- insig0  = InSig { _datain = DontCare,
     --                   _instr  = DontCare }
     -- outsig0 = OutSig { _fetch  = DontCare,
     --                    _read   = DontCare,
     --                    _write  = DontCare,
     --                    _extern = DontCare }

-- N.b., this doesn't hardware address and word sizes.
mkram :: (Monad m,Eq a,Num w,Show a,Show w) => ReacT (Port a, Port w) (Port w) m ()
mkram = ramsim (\ _ -> 0) (DontCare,DontCare)
--mkram = signal Complete >> mkram

ram0 :: Monad m => ReacT (Port W8, Port W8) (Port W8) m ()
ram0    = ramsim ((\ _ -> 0) :: W8 -> W8) (DontCare,DontCare)

ramw9 :: Monad m => ReacT (Port W8, Port W9) (Port W9) m ()
ramw9    = ramsim ((\ _ -> 0) :: W8 -> W9) (DontCare,DontCare)

im0 :: Monad m => ReacT (Port W8) (Port W8) m ()
im0 = mkinstrmem badcode

mkinstrmem code = romsim (assemble code) DontCare

badcode = [Push (W4 S S C C), Ret]
outcode = [Push (W4 C S C S), Output]

--
-- sink, if installed at the beginning of UNSAFE code, goes into an infinite loop
-- that outputs 0xF repeatedly.
--
sink = Push (W4 S S S S) :
       Output            :
       Push (W4 C C C C) :
       Jump              : []

callreturn = Push (W4 S C S C) :
             Push (W4 C S S C) : 
             Call              : -- call 6
             Push (W4 S S S S) :
             Output            :
             Nop               :
             Output            :
             Ret               : []

-- this should not set off alarm
callreturntest = Push (W4 C S C C) :
                 Jump              :
                 Output            : -- the output procedure
                 Ret               : 
                 Push (W4 S S S S) :
                 Push (W4 C C S C) : -- call the procedure to output 0b1111
                 Call              :
                 Push (W4 C C C C) :
                 Output            :
                 Nop               : []

-- this should set off alarm
calljumptest =   Push (W4 C S C C) :
                 Jump              :
                 Output            : -- the output procedure
                 Ret               :
                 Push (W4 S C C C) : -- bogus return label
                 Push (W4 S S S S) :
                 Push (W4 C C S C) : -- call the procedure to output 0b1111
                 Jump              : -- won't create integrity bit on return label
                 Push (W4 C C C C) : 
                 Output            :
                 Nop               : []


procfibcode = procfib (W4 S C C C) (W4 S C C S)

procfib _n _m = Push (W4 C S C C) :
                Jump              :
                Output            : -- the output procedure
                Ret               : 
                Push 0            : -- initialization code
                Push _n           :
                Store             :
                Push 1            :
                Push _m           :
                Store             :
                Push _n           : -- start of loop
                Load              :
                Push (W4 C C S C) : -- address of output procedure
                Call              : -- instead of Output instruction
                Push _n           :
                Load              :
                Push _m           :
                Load              :
                Add               :
                Push _m           :
                Load              :
                Push _n           :
                Store             :
                Push _m           :
                Store             :
                Push (W4 S C S C) : -- offset 10, start of loop
                Jump              : []

fibcode = fib (W4 S C C C) (W4 S C C S)

fib _n _m = Push 0  : -- initialization code
            Push _n :
            Store   :
            Push 1  :
            Push _m :
            Store   :
            Push _n : -- start of loop
            Load    :
            Output  :
            Push _n :
            Load    :
            Push _m :
            Load    :
            Add     :
            Push _m :
            Load    :
            Push _n :
            Store   :
            Push _m :
            Store   :
            Push (W4 C S S C) : -- offset 6
            Jump    : []

countercode = counter (W4 C S S S)

counter _c = Push 0  : -- initialization code
             Push _c :
             Store   :
             Push _c : -- start of loop
             Load    :
             Output  : -- output counter contents
             Push _c : 
             Load    :
             Push 1  :
             Add     :
             Push _c :
             Store   :
             Push (W4 C C S S) : -- offset 4
             Jump    : []

testingadd = Push (W4 C C C S) :
             Push (W4 C C S C) :
             Add               :
             Output            : []
