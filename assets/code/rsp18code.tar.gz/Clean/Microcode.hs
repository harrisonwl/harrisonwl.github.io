module Microcode where

import Control.Monad.State
import Control.Monad.Resumption.Reactive

import ComputerArithmetic
import MemoryModel

data Instr   = Add
             | Output
             | Push W4
             | Load
             | Store
             | Jump
             | Bnz W4
             | Call
             | Ret
             | Nop  -- added this for the hell of it.
               deriving Show

--
-- Not using this anymore.
--
-- type Address   = W8
-- type RegFile a = a
-- data Store a   = (Address,a) :>+ (Store a) | Nil
-- data Stack a   = a :> Stack a  -- regular atom on TOS
--                | Empty
--
-- (<?>) :: Store a -> Address -> a
-- Nil <?> j                        = undefined
-- ((i,a) :>+ dm) <?> j | i==j      = a
--                      | otherwise = dm <?> j
--
-- data Err = StkErr 
-- type E   = ExceptT Err Identity
-- type M   = StateT (Stack W8) (StateT (Store W8) (StateT (RegFile W8) E))

--
-- What follows are implementations of the "microcode" in terms of Gumnut operations.
-- Now, there is only one StateT layer.
--
getSP :: Monad m => ReacT i o (StateT ((pc,sp),ins,outs) m) sp
getSP = do
  ((_,sp),_,_) <- lift get
  return sp

putSP :: Monad m => sp -> ReacT i o (StateT ((pc,sp),ins,outs) m) ()
putSP sp = do
  ((pc,_),ins,outs) <- lift get
  lift $ put ((pc,sp),ins,outs)

getPC :: Monad m => ReacT i o (StateT ((pc,sp),ins,outs) m) pc
getPC = do
  ((pc,_),_,_) <- lift get
  return pc

putPC :: Monad m => pc -> ReacT i o (StateT ((pc,sp),ins,outs) m) ()
putPC pc = do
  ((_,sp),ins,outs) <- lift get
  lift $ put ((pc,sp),ins,outs)

toOutput :: Monad m => w -> ReacT (InSig w i) (OutSig a w w) (StateT (regs, InSig w i, OutSig a w w) m) ()
toOutput w = do
  (regs,ipts,opts) <- lift get
  lift $ put (regs,ipts, extern_ (Valid w) opts)
  tick

popM :: (Monad m,Num a,Num w,Show a,Show w) =>
        ReacT
           (InSig w i)
           (OutSig a w e)
           (StateT ((pc,a), InSig w i, OutSig a w e) m) w
popM = do
  sp <- getSP
  putSP (sp-1) --- a little more care, please
  async_read sp
  
pushM :: (Monad m, Num a, Show a, Show w) =>
         w  ->
         ReacT
          (InSig w i)
          (OutSig a w e)
          (StateT ((pc, a), InSig w i, OutSig a w e) m)
          ()
pushM w = do
  sp <- getSP
  let sp' = sp+1
  putSP sp' --- a little more care, please
  async_write sp' w

setloc :: (Monad m, Show a, Show w) =>
          a ->
          w ->
          ReacT
            (InSig w i)
            (OutSig a w e)
            (StateT (regs, InSig w i, OutSig a w e) m)
            ()
setloc a w = do
  async_write a w
  
getloc a = do
  async_read a

tick :: Monad m => ReacT (InSig w i) (OutSig a w e) (StateT (regs,InSig w i,OutSig a w e) m) ()
tick = do
  (_,_,o) <- lift get
  lift resetOutputs
  i'      <- signal o
  lift $ get >>= \ (s,_,o) -> put (s,i',o)

resetOutputs :: Monad m => StateT (regs,InSig w i,OutSig a w e) m ()
resetOutputs = do
  (regs,inports,outports) <- get
  put (regs,inports, extern_ DontCare (write_ DontCare (read_ DontCare outports)))
