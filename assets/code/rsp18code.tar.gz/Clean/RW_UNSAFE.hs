module RW_UNSAFE where

import Control.Monad.Identity
import Control.Monad.State
import Control.Monad.Resumption.Reactive
import Control.Monad.Resumption.Connectors

import ComputerArithmetic
import MemoryModel hiding (debug)
import Microcode

import Debug.Trace

--debug = trace
debug x y = y


unsafe :: Monad m =>
          Device
             (Port W8,Port W8)
             (Port W8,Port W8,Port W8,Port W8)
             ((W8,W8), InSig W8 W8, OutSig W8 W8 W8)
             m
unsafe = do
  pc        <- getPC
  iw <- async_fetch pc
  let instr = decode iw
  debug ("Executing Instr:" ++ show instr) $ do exec instr 
  unsafe 

decode :: W8 -> Instr
decode w8 = case w8 of
  W8 C C C C _  _  _  _  -> Add
  W8 C C C S b3 b2 b1 b0 -> Push (W4 b3 b2 b1 b0)
  W8 C C S C _  _  _  _  -> Load
  W8 C C S S _  _  _  _  -> Store
  W8 C S C C _  _  _  _  -> Jump
  W8 C S C S b3 b2 b1 b0 -> Bnz (W4 b3 b2 b1 b0)
  W8 C S S C _  _  _  _  -> Call
  W8 C S S S _  _  _  _  -> Ret
  W8 S C C C _  _  _  _  -> Output
  _                      -> debug ("Decoding " ++ show w8 ++ " as Nop") Nop

encode :: Instr -> W8
encode i = case i of
  Add                   -> W8 C C C C C  C  C  C 
  Push (W4 b3 b2 b1 b0) -> W8 C C C S b3 b2 b1 b0
  Load                  -> W8 C C S C C  C  C  C  
  Store                 -> W8 C C S S C  C  C  C  
  Jump                  -> W8 C S C C C  C  C  C 
  Bnz (W4 b3 b2 b1 b0)  -> W8 C S C S b3 b2 b1 b0 
  Call                  -> W8 C S S C C  C  C  C 
  Ret                   -> W8 C S S S C  C  C  C 
  Output                -> W8 S C C C C  C  C  C 
  Nop                   -> W8 S C C S C  C  C  C 

--
assemble :: [Instr] -> W8 -> W8
assemble is = tweekList (\ _ -> W8 S C C S C C C C) (zip nats8 (map encode is))
  where
    nats8 :: [W8]
    nats8 = gennats8 (W8 C C C C C C C C)
    gennats8 :: W8 -> [W8]
    gennats8 w8 = w8 : gennats8 (w8 + 1)
    tweek :: Eq a => a -> b -> (a -> b) -> a -> b
    tweek x v f = \ y -> if x==y then v else f y
    tweekList :: Eq a => (a -> b) -> [(a,b)] -> a -> b
    tweekList f []         = f
    tweekList f ((x,v):bs) = tweekList (tweek x v f) bs

-- removing this artifact of SAFE.
--data Out o   = Out o | Silent deriving Show
-- exec :: Monad m =>
--          Instr ->
--          ReacT (InSig W8 i) (OutSig W8 W8) (StateT ((W8,W8), InSig W8 i, OutSig W8 W8) m) (Out W8)

exec :: Monad m =>
         Instr ->
         ReacT (InSig W8 i) (OutSig W8 W8 W8) (StateT ((W8,W8), InSig W8 i, OutSig W8 W8 W8) m) ()
exec i = case i of
  Add -> do
    pc <- getPC
    n1 <- popM
    n2 <- popM
    pushM (n1+n2)
    putPC (pc + 1)
  Push n -> do
    pc <- getPC
    putPC $ pc + 1
    pushM $ w4Tow8 n
  Load   -> do
    pc <- getPC
    p  <- popM
    m  <- getloc p
    putPC $ pc + 1
    pushM m
  Store  -> do
    pc <- getPC
    p  <- popM
    m  <- popM
    setloc p m
    putPC $ pc + 1
  Jump   -> do
    pc' <- popM 
    putPC pc'
  Bnz k  -> do
    pc <- getPC
    m  <- popM
    let pc' = if m==0 then pc + 1 else w4Tow8 k
    putPC pc'
  Call   -> do -- this adheres to Tolmach et al's semantics.
    pc  <- getPC
    pc' <- popM
    arg <- popM
    putPC pc'
    pushM (pc + 1)
    pushM arg
  Ret    -> do
    pc <- getPC
    ra <- popM
    putPC ra
  Output  -> do
    pc <- getPC
    m  <- popM
    toOutput m -- write m to internal _output port
    putPC (pc + 1)
  Nop   -> do
    pc <- getPC
    putPC (pc+1)
