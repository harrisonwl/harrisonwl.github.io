module MemoryModel where

import Control.Monad.Identity
import Control.Monad.State
import Control.Monad.Resumption.Reactive
import Debug.Trace

--debug = trace
debug x y = y

data Port a = Valid a | DontCare | Complete deriving Show

type Device i o s m = ReacT i o (StateT s m) ()


-- data InSig w i  = InSig { _datain :: Port w
--                         , _instr  :: Port i }
--                   deriving Show

type InSig w i = (Port w,Port i)
_datain :: InSig w i -> Port w
_datain (pw,_) = pw
_instr (_,pi)  = pi
_instr  :: InSig w i -> Port i

-- data OutSig a w e = OutSig { _fetch  :: Port a
--                            , _read   :: Port a
--                            , _write  :: Port w
--                            , _extern :: Port e }
--                   deriving Show

type OutSig a w e = (Port a,Port a,Port w,Port e)

_fetch, _read :: OutSig a w e -> Port a
_write        :: OutSig a w e -> Port w
_extern       :: OutSig a w e -> Port e

_fetch (oi,da,dw,e)  = oi
_read (oi,da,dw,e)   = da
_write (oi,da,dw,e)  = dw
_extern (oi,da,dw,e) = e

fetch_ oi (_,da,dw,e)  = (oi,da,dw,e)
read_ da (oi,_,dw,e)   = (oi,da,dw,e)
write_ dw (oi,da,_,e)  = (oi,da,dw,e)
extern_ e (oi,da,dw,_) = (oi,da,dw,e)


       ------------------------------------------------------
       --         Asynchronous Read and Write              --
       ------------------------------------------------------

blank :: OutSig a w e
blank = (DontCare,DontCare,DontCare,DontCare)

async_read :: (Monad m,Show a) => a -> ReacT (InSig w i) (OutSig a w e) m w
async_read a = debug ("READ: a = " ++ show a) $ do
     os <- signal (readdata a)
     async_wait_read a os
   where
     async_wait_read a i = debug ("READ_WAIT: a = " ++ show a) $ case _datain i of
       Valid w -> return w
       _       -> do
          os <- signal (readdata a)
          async_wait_read a os
     readdata a = read_ (Valid a) blank

async_write :: (Monad m,Show a,Show w) => a -> w -> ReacT (InSig w i) (OutSig a w e) m ()
async_write a w = debug ("WRITE: a,w = " ++ show a ++ "," ++ show w) $ do
     os <- signal (writedata a w)
     async_wait_write a w os
   where
     async_wait_write a w i = debug ("WRITE_WAIT: a,w = " ++ show a ++ "," ++ show w) $ case _datain i of
       Complete -> return ()
       _        -> do
          os <- signal (writedata a w)
          async_wait_write a w os
     writedata a w = write_ (Valid w) (read_ (Valid a) blank)

       ---------------------------------------------------------
       --            Asynchronous instruction fetch           --
       ---------------------------------------------------------

async_fetch :: (Monad m, Show a) => a -> ReacT (InSig w i) (OutSig a w e) m i
async_fetch a = do
     os <- signal (fetchinstr a)
     debug ("FETCH: a = " ++ show a) $ async_wait_fetch a os
   where
     async_wait_fetch a i = case _instr i of
       Valid w -> return w
       _       -> do
          os <- signal (fetchinstr a)
          debug ("FETCH_WAIT: a = " ++ show a) $ async_wait_fetch a os
     fetchinstr a = fetch_ (Valid a) blank 

       ---------------------------------------------------------
       --                 RAM and ROM instances               --
       ---------------------------------------------------------

ramsim :: (Eq a, Monad m,Show a,Show w) =>
          (a -> w) -> (Port a, Port w) -> ReacT (Port a, Port w) (Port w) m ()
ramsim sigma (ma,mm) = case (ma,mm) of
  -- Write a m
  (Valid a,Valid m)  -> do
     signal DontCare
     signal DontCare
     debug ("\n\nCOMPLETE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n\n") $ do signal Complete
     (ma',mm') <- signal DontCare
     ramsim (tweek a m sigma) (ma', mm')
         where
           tweek x v m = \ y -> if x==y then v else m y
  -- Read a
  (Valid a,_) ->  debug ("\n\nWTF1!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n\n") $ do
     signal DontCare -- wait a cycle, ignoring input
     signal (Valid $ sigma a)
     (ma',mm') <- signal DontCare
     ramsim sigma (ma', mm')
  (_,_)      ->      debug ("\n\nWTF2!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n\n") $ do
     (ma',mm') <- signal DontCare
     ramsim sigma (ma', mm')

romsim :: Monad m => (a -> w) -> Port a -> ReacT (Port a) (Port w) m ()
romsim sigma ma = case ma of
  Valid a  -> do
    signal DontCare -- wait a cycle, ignoring input
    signal (Valid $ sigma a)
    ma' <- signal DontCare
    romsim sigma ma'  
  _        -> do
    ma' <- signal DontCare
    romsim sigma ma'

-----------------------------------------
-- Testing Routines
-----------------------------------------

splat :: (Read t, Show a) => ReacT t a (StateT t2 Identity) t1 -> t2 -> IO ()
splat (ReacT phi) s = do
  let Identity (r,s') = runStateT phi s
  case r of
   Left _  -> putStrLn "????"
   Right (o,k) -> do
     putStrLn $ "Output: " ++ show o
     putStrLn $ "Enter Input:"
     i <- getLine
     splat (k (read i)) s'

spl :: Show a => ReacT () a (StateT t2 Identity) t1 -> t2 -> IO ()
spl (ReacT phi) s = do
  let Identity (r,s') = runStateT phi s
  case r of
   Left _  -> putStrLn "????"
   Right (o,k) -> do
     putStrLn $ "Output: " ++ show o
     putStrLn $ "Enter Input:"
     i <- getLine
     spl (k ()) s'

rundev :: ReacT i o (StateT s Identity) () -> [i] -> s -> [(i,s,o)] 
rundev _ [] _               = []
rundev (ReacT phi) (i:is) s = case lr of
  (Left v,s')      -> []
  (Right (o,r),s') -> (i,s,o) : rundev (r i) is s'
  where Identity lr = runStateT phi s

stepdev :: ReacT i o (StateT s Identity) () -> i -> s -> Either () (i,s,o)
stepdev (ReacT phi) i s = case lr of
  (Left v,s')      -> Left v
  (Right (o,r),s') -> Right (i,s,o)
  where Identity lr = runStateT phi s
 
-- for debugging, the signalIO and unroll can help. Not used here.
signalIO :: (Show o, Read i) => o -> IO i
signalIO o = do
  putStrLn $ "Output: " ++ show o
  putStrLn $ "Enter Input:"
  i <- getLine
  return (read i)

-- -- use case: unroll fde s0
-- unroll :: ReacT t t1 (StateT s IO) t2 -> s -> IO ()
-- unroll (ReacT phi) s = do
--   (r,s') <- runStateT phi s
--   case r of
--    Right (o,k) -> unroll (k (error "should not be seen")) s'
--    Left _      -> putStrLn "???????"


{-
pristine working copy (kruft at this point)

instr_fetch_async :: (Monad m, Show pc) =>
                     pc     ->
                     ReacT (InSig w i) (OutSig pc w) (StateT (registers, InSig w i, OutSig pc w) m) i
instr_fetch_async pc = debug ("MM.instr_fetch_async: pc = " ++ show pc ) $ do
  lift $ instr_fetch_init pc
  tick
  wait4ack_fetch pc

wait4ack_fetch :: (Monad m, Show a) => a -> ReacT (InSig w i) (OutSig a w) (StateT (regs,InSig w i,OutSig a w) m) i
wait4ack_fetch a = debug ("MM.wait4ack_fetch: pc = " ++ show a ) $ do
  (_,inports,_) <- lift get
  lift $ instr_fetch_reset
  case _instr inports of
   DontCare  -> do
     tick
     wait4ack_fetch a
   Complete  -> do
     tick
     wait4ack_fetch a
   Valid i -> do
--     lift data_postrw -- This doesn't make any sense???
     return $ debug "MM.DONE: wait4ack_fetch" i

instr_fetch_init :: Monad m => pc -> StateT (registers,inports,OutSig pc w) m ()
instr_fetch_init pc = do
  (r,ins,outs) <- get
  put (r,ins,outs { _fetch = Just pc })

instr_fetch_reset :: Monad m => StateT (registers,inports,OutSig pc w) m ()
instr_fetch_reset = do
  (r,ins,outs) <- get
  put (r,ins,outs { _fetch = Nothing })
-}

{- Moe kruft

-- tick :: Monad m => ReacT i o (StateT (s,i,o) m) ()
-- tick = do
--   (_,_,o) <- lift get
--   i'      <- signal o
--   lift $ get >>= \ (s,_,o) -> put (s,i',o)

tick :: Monad m => ReacT (InSig w i) (OutSig a w) (StateT (regs,InSig w i,OutSig a w) m) ()
tick = do
  (_,_,o) <- lift get
  lift resetOutputs
  i'      <- signal o
  lift $ get >>= \ (s,_,o) -> put (s,i',o)

resetOutputs :: Monad m => StateT (regs,InSig w i,OutSig a w) m ()
resetOutputs = do
  (regs,inports,outports) <- get
  put (regs,inports, outports { _read = Nothing, _write = Nothing, _extern = DontCare })

postrw :: OutSig a w -> OutSig a w
postrw outsig = outsig { _read = Nothing, _write = Nothing }

data_postrw :: Monad m => StateT (registers,inports,OutSig a w) m ()
data_postrw = do
  (rb,dins,dout) <- get
  put (rb,dins,postrw dout)

-- getDataMDR :: (Monad m, Num w) => StateT (registers,InSig w i,outports) m w
-- getDataMDR = do
--   (_,inbound,_) <- get
--   return $ purify $ _datain inbound
--     where
--       purify :: Num a => Maybe a -> a
--       purify (Just v) = v
--       purify Nothing  = 0

getDataMDR :: (Monad m, Num w) => StateT (registers,InSig w i,outports) m w
getDataMDR = do
  (_,inbound,_) <- get
  return $ purify $ _datain inbound
    where
      purify :: Num a => Port a -> a
      purify (Valid v) = v
      purify Complete  = 0
      purify DontCare  = 0

data_rd_init :: Monad m => a -> StateT (registers,inports,OutSig a w) m ()
data_rd_init a = get >>= (\ (reg,mi,mo) -> put (reg,mi,rd_init a mo) )
   where
     rd_init :: a -> OutSig a w -> OutSig a w
     rd_init a outsig = outsig { _read = Just a }

data_wr_init :: Monad m => a -> w -> StateT (registers,InSig w i,OutSig a w) m ()
data_wr_init a w = get >>= (\ (rb,data_i,data_o) -> put (rb,data_i,wr_init a w data_o))
   where
     wr_init :: a -> w -> OutSig a w -> OutSig a w
     wr_init a w outbound = outbound { _write = Just (a,w) }


-- ------------------------------------------------------
-- --         Synchronous Read and Write               --
-- ------------------------------------------------------

-- datawrite_sync :: Monad m =>
--                   a     ->
--                   w     ->
--                   ReacT (InSig w i) (OutSig a w) (StateT (regs, InSig w i, OutSig a w) m) ()
-- datawrite_sync a w = do
--   lift $ data_wr_init a w
--   tick
--   lift $ data_postrw

-- dataread_sync :: (Monad m, Num w) =>
--                  a ->
--                  ReacT (InSig w i) (OutSig a w) (StateT (regs, InSig w i, OutSig a w) m) w
-- dataread_sync a = do
--  lift $ data_rd_init a
--  tick
--  lift $ do
--     data_postrw
--     getDataMDR


-- working version
-- dataread_async :: (Monad m,Show a,Show w) => a -> ReacT (InSig w i) (OutSig a w) (StateT (regs,InSig w i,OutSig a w) m) w
-- dataread_async a = debug ("MM.dataread_async: a = " ++ show a) $ do
--   lift $ data_rd_init a
--   tick  
--   wait4ack_read a

wait4ack_read :: (Monad m, Show a, Show w) => a -> ReacT (InSig w i) (OutSig a w) (StateT (regs,InSig w i,OutSig a w) m) w
wait4ack_read a = debug ("MM.wait4ack_read: a = " ++ show a) $ do
  (_,inports,_) <- lift get
  case _datain inports of
   DontCare  -> do
     lift $ data_rd_init a
     tick
     wait4ack_read a
   Complete  -> do
     lift $ data_rd_init a
     tick
     wait4ack_read a
   Valid msg -> do
     lift data_postrw
     return $ debug ("MM.DONE: wait4ack_read " ++ show msg) msg

-- new version
datawrite_async :: Monad m => a -> w -> ReacT (InSig w i) (OutSig a w) m ()
datawrite_async a w = signal (writedata a w) >>= async_wait_write a w
   where
     async_wait_write a w i = case _datain i of
       Complete -> {- "postrw-step" signal blank >> -} return ()
       _        -> signal (writedata a w) >>= async_wait_write a w

     writedata a w = blank { _write = Just (a,w) }

-- working version
-- datawrite_async :: (Monad m, Show a, Show w) =>
--                    a ->
--                    w ->
--                    ReacT (InSig w i) (OutSig a w) (StateT (regs,InSig w i,OutSig a w) m) ()
-- datawrite_async a w = debug ("MM.datawrite_async: a w = " ++ show a ++ "," ++ show w) $ do
--   lift $ data_wr_init a w
--   tick
--   wait4ack_write a w

wait4ack_write a w = debug ("MM.wait4ack_write: a w = " ++ show a ++ "," ++ show w) $ do
  (_,inports,_) <- lift get
  case _datain inports of
   DontCare  -> do
     lift $ data_wr_init a w
     debug ("MM.WAITING in wait4ack_write") tick
     wait4ack_write a w
   Complete -> do
     lift data_postrw
     return $ debug "MM.DONE: wait4ack_write" ()
   Valid _ -> do
     lift $ data_wr_init a w
     debug ("MM.WAITING in wait4ack_write") tick
     wait4ack_write a w



-}

-- -- new version
-- dataread_async :: Monad m => a -> ReacT (InSig w i) (OutSig a w) m w
-- dataread_async a = signal (readdata a) >>= async_wait_read a
--    where

--      async_wait_read a i = case _datain i of
--        Valid w -> {- "postrw-step" signal blank >> -} return w
--        _       -> signal (readdata a) >>= async_wait_read a

--      readdata a = blank { _read = Just a }

{-
simplified, nonfunctioning version
instr_fetch_async :: Monad m => a -> ReacT (InSig w i) (OutSig a w) m i
instr_fetch_async a = signal (fetchinstr a) >>= async_wait_fetch a
   where
   --  old version only kept the fetch signal high for one cycle
   --  lift $ instr_fetch_reset

     async_wait_fetch :: Monad m => a -> InSig w i -> ReacT (InSig w i) (OutSig a w) m i
     async_wait_fetch a i = case _instr i of
                                 Valid w -> return w
                                 _       -> signal (fetchinstr a) >>= async_wait_fetch a

     fetchinstr a = blank { _fetch = Just a }
-}

-- pristine working version
-- romsim :: Monad m => (a -> w) -> Maybe a -> ReacT (Maybe a) (Maybe w) m ()
-- romsim sigma (Just a) = do
--   signal Nothing -- wait a cycle, ignoring input
--   signal (Just $ sigma a)
--   ma' <- signal Nothing
--   romsim sigma ma'
-- romsim sigma Nothing = do
--   ma' <- signal Nothing
--   romsim sigma ma'
