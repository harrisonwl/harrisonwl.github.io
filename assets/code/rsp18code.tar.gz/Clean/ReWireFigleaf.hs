module ReWireFigleaf where

import Control.Monad.Identity
import Control.Monad.State
import Control.Monad.Resumption.Reactive
import Control.Monad.Resumption.Connectors

---
--- Below is, more or less, the ReWire figleaf.
---

(<&>) :: Monad m =>
         ReacT i1 o1 (StateT s1 m) () ->
         ReacT i2 o2 (StateT s2 m) () ->
         ReacT (i1,i2) (o1,o2) (StateT (s1,s2) m) () 
(ReacT phi1) <&> (ReacT phi2) = ReacT $ (phi1 .&. phi2) >>= \ (Right (o1,k1),Right (o2,k2)) ->
                                        return (Right ((o1,o2),\ (i1,i2) -> k1 i1 <&> k2 i2))

(.&.) :: (Monad m) => StateT s1 m a -> StateT s2 m b -> StateT (s1,s2) m (a,b)
(StateT phi1) .&. (StateT phi2) = StateT $ \ (s1,s2) ->  phi1 s1 >>= \ (v1,sto1) ->
                                                         phi2 s2 >>= \ (v2,sto2) ->
                                                         return ((v1,v2),(sto1,sto2))

-- whatever.
(<&&>) :: Monad m =>
          ReacT i1 o1 (StateT s1 m) () ->
          ReacT i2 o2 m ()             ->
          ReacT (i1,i2) (o1,o2) (StateT s1 m) () 
(ReacT phi1) <&&> (ReacT phi2) = ReacT $ (phi1 .&&. phi2) >>= \ (Right (o1,k1),Right (o2,k2)) ->
                                         return (Right ((o1,o2),\ (i1,i2) -> k1 i1 <&&> k2 i2))

(.&&.) :: (Monad m) => StateT s1 m a -> m b -> StateT s1 m (a,b)
(StateT phi1) .&&. phi2 = StateT $ \ s1 ->  phi1 s1 >>= \ (v1,sto1) ->
                                            phi2    >>= \ v2 ->
                                            return ((v1,v2),sto1)
