module MonitorStackIntegrity where

import Control.Monad.Identity
import Control.Monad.State
import Control.Monad.Resumption.Reactive

import ComputerArithmetic
import MemoryModel hiding (debug)

-- data InMon = InMon { _iword :: Port W8 -- instruction word; need to know if call or return instruction
--                    , _integ :: Port Bit -- just the integrity bit
--                    , _reset :: Bit }    -- reset means "jump back to stack_integrity"
--              deriving Show

type InMon = (Port W8,Port Bit,Bit)

_iword :: InMon -> Port W8
_integ :: InMon -> Port Bit
_reset :: InMon -> Bit
_iword (pw8,_,_) = pw8
_integ (_,pb,_)  = pb
_reset (_,_,b)   = b

iword_ :: Port W8 -> InMon -> InMon
integ_ :: Port Bit -> InMon -> InMon
reset_ :: Bit -> InMon -> InMon
iword_ pw8 (_,pb,b) = (pw8,pb,b)
integ_ pb (pw8,_,b) = (pw8,pb,b)
reset_ b (pw8,pb,_) = (pw8,pb,b)

-- data OutMon = OutMon { _alarm :: Bit
--                      , _ibit  :: Bit }
--               deriving Show

type OutMon = (Bit,Bit)
_alarm (alarm,_) = alarm
_ibit (_,ib)     = ib

alarm_ alarm (_,ib) = (alarm,ib)
ibit_ ib (alarm,_)  = (alarm,ib)

all_quiet :: OutMon
all_quiet = (C,C)

-----------------------------------
-- this is the integrity monitor --
-----------------------------------

check_reset :: Monad m => InMon -> ReacT InMon OutMon m ()
check_reset i = case _reset i of
  C -> return ()
  S -> stack_integrity

-- integrity_monitor :: Monad m => ReacT InMon OutMon m ()
-- integrity_monitor = do
--       i <- signal all_quiet
--       check_reset i
--       case _iword i of
--         -- Call
--         Just (W8 C S S C _  _  _  _) -> do
--           check_read C
--           check_read C
--           signal (OutMon { _alarm = C, _ibit = S })
--           check_write
--           check_write
--           integrity_monitor
--         -- Ret
--         Just (W8 C S S S _  _  _  _) -> do
--           check_read S
--           integrity_monitor
--         -- irrelevant instructions
--         _                            -> integrity_monitor
--    where
--       check_reset i = case _reset i of
--         C -> return ()
--         S -> integrity_monitor
  
stack_integrity :: Monad m => ReacT InMon OutMon m ()
-- Device (Port W8,Port Bit,Bit) (Bit,Bit) 
stack_integrity = do
  i <- signal all_quiet
  check_reset i
  case _iword i of
   -- Call
   Valid (W8 C S S C _  _  _  _) -> call
   -- Ret
   Valid (W8 C S S S _  _  _  _) -> ret
   -- irrelevant instructions
   _                             -> stack_integrity


call, ret :: Monad m => ReacT InMon OutMon m ()

-- N.b., that Call makes two successive memory reads (popM x 2), followed
--       by two successive memory writes (pushM x 2)
--       The first pushM (i.e., "pushM $ pc + 1") is writing the return address out to
--       memory and, hence, the integrity bit should be set (but only during this write).
call = do
  check_read C
  check_read C
  signal (ibit_ S all_quiet)
  check_write
  check_write
  stack_integrity

-- N.b., the Ret instruction makes a single memory read, during which it reads the
--       return address off of the stack in data memory. This address should have
--       the integrity bit set, or else the alarm is raised. A raised alarm will
--       remain raised until a _reset signal is received.
ret = do
  check_read S
  stack_integrity

check_read :: Monad m => Bit -> ReacT InMon OutMon m ()
check_read b = do
  i <- signal all_quiet
  check_reset i
  wait4valid i

  where

    wait4valid :: Monad m => InMon -> ReacT InMon OutMon m ()
    wait4valid i = do
      check_reset i
      case (b,_integ i) of
        (C,Valid _) -> return () -- on C, return if Valid
        (S,Valid S) -> return () -- on S, return if integrity bit set
        (S,Valid C) -> integrity_alarm
        _           -> signal all_quiet >>= wait4valid

    integrity_alarm :: Monad m => ReacT InMon OutMon m ()
    integrity_alarm = do
      i <- signal ((S,S) :: OutMon)
      check_reset i
      integrity_alarm

check_write :: Monad m => ReacT InMon OutMon m ()
check_write = do
  i <- signal all_quiet
  check_reset i
  wait4complete i
  where
    wait4complete :: Monad m => InMon -> ReacT InMon OutMon m ()
    wait4complete inmon = do
      check_reset inmon
      case _integ inmon of
        Complete -> return () 
        _  -> do
          i <- signal all_quiet
          wait4complete i

-- ckread_stale :: Monad m => ReacT InMon OutMon m ()
-- ckread_stale = do
--   i <- signal all_quiet
--   check_reset i
--   wait4valid i
--   where
--     wait4valid :: Monad m => InMon -> ReacT InMon OutMon m ()
--     wait4valid i = do
--       check_reset i
--       case _integ i of
--         Valid _ -> return () 
--         _       -> signal all_quiet >>= wait4valid


-- checkread :: Monad m => ReacT InMon OutMon m ()
-- checkread = do
--   i <- signal all_quiet
--   check_reset i
--   wait4valid i
--   where
--     wait4valid :: Monad m => InMon -> ReacT InMon OutMon m ()
--     wait4valid i = do
--       check_reset i
--       case _integ i of
--         Valid ib -> case ib of
--           S -> return () -- everything's ok, has integrity bit set
--           C -> integrity_alarm
--         _        -> signal all_quiet >>= wait4valid

--     integrity_alarm :: Monad m => ReacT InMon OutMon m ()
--     integrity_alarm = do
--       i <- signal $ OutMon { _alarm = S, _ibit = S }
--       check_reset i
--       integrity_alarm
