module Main where

import Control.Monad.Identity
import Control.Monad.State
import Control.Monad.Resumption.Reactive
import Control.Monad.Resumption.Connectors

import ComputerArithmetic hiding ((<+>))
import MemoryModel hiding (debug)
import Microcode
import RW_UNSAFE hiding (debug)
import MonitorStackIntegrity hiding (debug)

splitW9 :: Port W9 -> (Port W8, Port Bit)
splitW9 (Val (W9 b7 b6 b5 b4 b3 b2 b1 b0 ib))
     = (Val (W8 b7 b6 b5 b4 b3 b2 b1 b0), Val ib)
splitW9 Cmp = (Cmp,Cmp)
splitW9 DC = (DC,DC)

--------------------------------------------
--               Simulator                --
--------------------------------------------

connect dev out conn = refold out conn dev

simulator proc code = connect
                         (proc <&> (mkinstrmem code <&> mkram))

(<+>) :: (int_out -> ext_inp -> int_inp1) ->
         (int_out -> ext_inp -> int_inp2) ->
         (int_out -> ext_inp -> (int_inp1, int_inp2))
f <+> g = \ int_out ext_inp -> (f int_out ext_inp, g int_out ext_inp)

--------------------------------------------
--         Generic Monitor Pattern        --
--------------------------------------------

monitor :: Monad m =>
           Device (dw, iw) o s1 m                    -> -- proc
           Device (iw, ibit, reset) (alarm, mo) s2 m -> -- monitor
           ((o, mo) -> o')                           -> -- combine
           (i' -> ((dw, iw), ibit))                  -> -- sample
           Device (i', reset) (o', alarm) (s1, s2) m
monitor p m c s = connect
                    (p <&> m)
                    out
                    conn
   where
     out (o,mo)        = (c (o,_ibit mo),_alarm mo)
     conn _ (i',reset)  = ((dw,iw),(iw,ibit,reset))
        where
           ((dw,iw),ibit) = s i'

----------------------------------------------------------
--  This is SAFER: Composing the processor and monitor   --
----------------------------------------------------------

safer :: Monad m =>
        Device
           ((Port W9, Port W8),Bit)
           ((Port W8, Port W8, Port W9, Port W8),Bit)
           (((W8, W8), InSig W8 W8, OutSig W8 W8 W8), s2)
           m
safer = monitor unsafe stack_integrity combine sample
   where
     combine :: (OutSig a W8 e,Bit) -> OutSig a W9 e
     combine ((i,r,d,e),ibit) = (i,r,joinW9 d ibit,e)

     sample :: InSig W9 i -> ((Port W8, Port i), Port Bit)
     sample insigW9 = ((dw,iw),ibit)
       where
         iw        = _instr insigW9
         din       = _datain insigW9
         (dw,ibit) = splitW9 din

joinW9 outsigW8 ibit = case outsigW8 of
   Val (W8 b7 b6 b5 b4 b3 b2 b1 b0) -> Val (W9 b7 b6 b5 b4 b3 b2 b1 b0 ibit)
   DC                           -> DC
   Cmp                           -> Cmp

--------------------------------------------
--         Unmonitored System             --
--------------------------------------------

mkunsafe :: Monad m =>
            [UNSAFE] ->
            ReacT () (Port W8)
               (StateT (((W8, W8), InSig W8 W8, OutSig W8 W8 W8), (s1, s2)) m)
               ()
mkunsafe code = simulator unsafe code unsafe_out connunsafe
  where
    unsafe_out :: (OutSig a w e, (t, t1)) -> Port e
    unsafe_out (outfde,(_,_)) = _extern outfde
    connunsafe = conn_unsafe_1 <+> (conn_unsafe_2 <+> conn_unsafe_3)
    conn_unsafe_1 (_,(miw,iosig)) () = (iosig,miw)
    conn_unsafe_2 (outsig,(_,_)) () = _fetch outsig
    conn_unsafe_3 (outsig,(_,_)) () = (_read outsig, _write outsig)

--------------------------------------------
--          Monitored System              --
--------------------------------------------

mksafer :: Monad m =>
          [UNSAFE]   ->
          ReacT Bit (Port W8, Bit)
                (StateT ((((W8, W8), InSig W8 W8, OutSig W8 W8 W8), s4), (s1, s2)) m)
                ()
mksafer code = simulator safer code out_safer_sys conn_safer_sys
  where
    out_safer_sys :: ((OutSig a w e, t2), (t, t1)) -> (Port e, t2)
    out_safer_sys ((outsigW9,alarm),(_,_)) = (_extern outsigW9,alarm)

    conn_safer_sys :: ((OutSig a w1 e, t), (Port i, Port w)) ->
                      Bit                                    ->
                      ((InSig w i, Bit), (Port a, (Port a, Port w1)))
    conn_safer_sys = conn_safer_sys1 <+> (conn_safer_sys2 <+> conn_safer_sys3)

    conn_safer_sys1 :: ((a, b), (Port i, Port w)) -> Bit -> (InSig w i, Bit)
    conn_safer_sys1 ((_,_),(instr,indata)) reset = ((indata,instr),reset)

    conn_safer_sys2 ((outsig,_),(_,_)) _ = _fetch outsig
    conn_safer_sys3 ((outsig,_),(_,_)) _ = (_read outsig, _write outsig)


--------------------------------------------
--        test harness & cases            --
--------------------------------------------

testunsafe :: [UNSAFE] -> Int -> [Port W8]
testunsafe code n = map (\ (_,_,z) -> z) $ rundev (mkunsafe code) (take n (repeat ())) s0

testsafer :: [UNSAFE] -> Int -> [(Port W8, Bit)]
testsafer code n   = map (\ (_,_,z) -> z) $ rundev (mksafer code) (take n (repeat C)) s0'

rundev :: ReacT i o (StateT s Identity) () -> [i] -> s -> [(i,s,o)] 
rundev _ [] _               = []
rundev (ReacT phi) (i:is) s = case lr of
  (Left v,s')      -> []
  (Right (o,r),s') -> (i,s,o) : rundev (r i) is s'
  where Identity lr = runStateT phi s

isValid (Val _) = True
isValid _       = False

s0 :: (((W8, W8), InSig W8 W8, OutSig W8 W8 W8), (String, String))
s0 = (((W8 C C C C C C C C, W8 C S S C C S C C), insig0, outsig0), ("undef", "und"))

s0' = ((((W8 C C C C C C C C, W8 C S S C C S C C), insig0, outsig0), "undef"),("undef", "und"))

insig0  = (DC,DC)
outsig0 = (DC,DC,DC,DC)

-- N.b., this doesn't hardwire address and word sizes.
mkram :: (Monad m,Eq a,Num w,Show a,Show w) => ReacT (Port a, Port w) (Port w) m ()
mkram = ramsim (\ _ -> 0) (DC,DC)

ram0 :: Monad m => ReacT (Port W8, Port W8) (Port W8) m ()
ram0    = ramsim ((\ _ -> 0) :: W8 -> W8) (DC,DC)

ramw9 :: Monad m => ReacT (Port W8, Port W9) (Port W9) m ()
ramw9    = ramsim ((\ _ -> 0) :: W8 -> W9) (DC,DC)

mkinstrmem code = romsim (assemble code) DC

--------
-------- here are the test cases for the paper
--------

badcode = [Push (W4 S S C C), Ret]
outcode = [Push (W4 C S C S), Output]

--
-- sink, if installed at the beginning of UNSAFE code, goes into an infinite loop
-- that outputs 0xF repeatedly.
--
sink = Push (W4 S S S S) :
       Output            :
       Push (W4 C C C C) :
       Jump              : []

callreturn = Push (W4 S C S C) :
             Push (W4 C S S C) : 
             Call              : -- call 6
             Push (W4 S S S S) :
             Output            :
             Nop               :
             Output            :
             Ret               : []

-- this should not set off alarm
callreturntest = Push (W4 C S C C) :
                 Jump              :
                 Output            : -- the output procedure
                 Ret               : 
                 Push (W4 S S S S) :
                 Push (W4 C C S C) : -- call the procedure to output 0b1111
                 Call              :
                 Push (W4 C C C C) :
                 Output            :
                 Nop               : []

-- this should set off alarm
calljumptest =   Push (W4 C S C C) :
                 Jump              :
                 Output            : -- the output procedure
                 Ret               :
                 Push (W4 S C C C) : -- bogus return label
                 Push (W4 S S S S) :
                 Push (W4 C C S C) : -- call the procedure to output 0b1111
                 Jump              : -- won't create integrity bit on return label
                 Push (W4 C C C C) : 
                 Output            :
                 Nop               : []


procfibcode = procfib (W4 S C C C) (W4 S C C S)

procfib _n _m = Push (W4 C S C C) :
                Jump              :
                Output            : -- the output procedure
                Ret               : 
                Push 0            : -- initialization code
                Push _n           :
                Store             :
                Push 1            :
                Push _m           :
                Store             :
                Push _n           : -- start of loop
                Load              :
                Push (W4 C C S C) : -- address of output procedure
                Call              : -- instead of Output instruction
                Push _n           :
                Load              :
                Push _m           :
                Load              :
                Add               :
                Push _m           :
                Load              :
                Push _n           :
                Store             :
                Push _m           :
                Store             :
                Push (W4 S C S C) : -- offset 10, start of loop
                Jump              : []

fibcode = fib (W4 S C C C) (W4 S C C S)

fib _n _m = Push 0  : -- initialization code
            Push _n :
            Store   :
            Push 1  :
            Push _m :
            Store   :
            Push _n : -- start of loop
            Load    :
            Output  :
            Push _n :
            Load    :
            Push _m :
            Load    :
            Add     :
            Push _m :
            Load    :
            Push _n :
            Store   :
            Push _m :
            Store   :
            Push (W4 C S S C) : -- offset 6
            Jump    : []

countercode = counter (W4 C S S S)

counter _c = Push 0  : -- initialization code
             Push _c :
             Store   :
             Push _c : -- start of loop
             Load    :
             Output  : -- output counter contents
             Push _c : 
             Load    :
             Push 1  :
             Add     :
             Push _c :
             Store   :
             Push (W4 C C S S) : -- offset 4
             Jump    : []

testingadd = Push (W4 C C C S) :
             Push (W4 C C S C) :
             Add               :
             Output            : []

---
--- Below is, more or less, the ReWire figleaf. 
---

(<&>) :: Monad m =>
         ReacT i1 o1 (StateT s1 m) () ->
         ReacT i2 o2 (StateT s2 m) () ->
         ReacT (i1,i2) (o1,o2) (StateT (s1,s2) m) () 
(ReacT phi1) <&> (ReacT phi2) = ReacT $ (phi1 .&. phi2) >>= \ (Right (o1,k1),Right (o2,k2)) ->
                                        return (Right ((o1,o2),\ (i1,i2) -> k1 i1 <&> k2 i2))

(.&.) :: (Monad m) => StateT s1 m a -> StateT s2 m b -> StateT (s1,s2) m (a,b)
(StateT phi1) .&. (StateT phi2) = StateT $ \ (s1,s2) ->  phi1 s1 >>= \ (v1,sto1) ->
                                                         phi2 s2 >>= \ (v2,sto2) ->
                                                         return ((v1,v2),(sto1,sto2))

(<&&>) :: Monad m =>
          ReacT i1 o1 (StateT s1 m) () ->
          ReacT i2 o2 m ()             ->
          ReacT (i1,i2) (o1,o2) (StateT s1 m) () 
(ReacT phi1) <&&> (ReacT phi2) = ReacT $ (phi1 .&&. phi2) >>= \ (Right (o1,k1),Right (o2,k2)) ->
                                         return (Right ((o1,o2),\ (i1,i2) -> k1 i1 <&&> k2 i2))

(.&&.) :: (Monad m) => StateT s1 m a -> m b -> StateT s1 m (a,b)
(StateT phi1) .&&. phi2 = StateT $ \ s1 ->  phi1 s1 >>= \ (v1,sto1) ->
                                            phi2    >>= \ v2 ->
                                            return ((v1,v2),sto1)
