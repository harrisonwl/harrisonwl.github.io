module MonitorStackIntegrity where

import Control.Monad.Identity
import Control.Monad.State
import Control.Monad.Resumption.Reactive

import ComputerArithmetic
import MemoryModel hiding (debug)

type InMon = (Port W8,Port Bit,Bit)

_iword :: InMon -> Port W8
_integ :: InMon -> Port Bit
_reset :: InMon -> Bit
_iword (pw8,_,_) = pw8
_integ (_,pb,_)  = pb
_reset (_,_,b)   = b

iword_ :: Port W8 -> InMon -> InMon
integ_ :: Port Bit -> InMon -> InMon
reset_ :: Bit -> InMon -> InMon
iword_ pw8 (_,pb,b) = (pw8,pb,b)
integ_ pb (pw8,_,b) = (pw8,pb,b)
reset_ b (pw8,pb,_) = (pw8,pb,b)

type OutMon = (Bit,Bit)
_alarm (alarm,_) = alarm
_ibit (_,ib)     = ib

alarm_ alarm (_,ib) = (alarm,ib)
ibit_ ib (alarm,_)  = (alarm,ib)

all_quiet :: OutMon
all_quiet = (C,C)

-----------------------------------
-- this is the integrity monitor --
-----------------------------------

check_reset :: Monad m => Bit -> ReacT InMon OutMon m ()
check_reset reset = case reset of
  C -> return ()
  S -> stack_integrity
  
stack_integrity :: Monad m => ReacT InMon OutMon m ()
stack_integrity = do
  (pw,pi,r) <- signal all_quiet
  check_reset r
  case pw of
   -- Call
   Val (W8 C S S C _  _  _  _) -> call
   -- Ret
   Val (W8 C S S S _  _  _  _) -> ret
   -- irrelevant instructions
   _                           -> stack_integrity


call, ret :: Monad m => ReacT InMon OutMon m ()

-- N.b., that Call makes two successive memory reads (popM x 2), followed
--       by two successive memory writes (pushM x 2)
--       The first pushM (i.e., "pushM $ pc + 1") is writing the return address out to
--       memory and, hence, the integrity bit should be set (but only during this write).
call = do
  check_read C
  check_read C
  signal (ibit_ S all_quiet)
  check_write
  check_write
  stack_integrity

-- N.b., the Ret instruction makes a single memory read, during which it reads the
--       return address off of the stack in data memory. This address should have
--       the integrity bit set, or else the alarm is raised. A raised alarm will
--       remain raised until a _reset signal is received.
ret = do
  check_read S
  stack_integrity

check_read :: Monad m => Bit -> ReacT InMon OutMon m ()
check_read b = do
  (pw,pi,r) <- signal all_quiet
  check_reset r
  wait4valid (pw,pi,r)

  where

    wait4valid :: Monad m => InMon -> ReacT InMon OutMon m ()
    wait4valid (_,integ,reset) = do
      check_reset reset
      case (b,integ) of
        (C,Val _) -> return () -- on C, return if Valid
        (S,Val S) -> return () -- on S, return if integrity bit set
        (S,Val C) -> integrity_alarm
        _           -> signal all_quiet >>= wait4valid

    integrity_alarm :: Monad m => ReacT InMon OutMon m ()
    integrity_alarm = do
      (_,_,reset) <- signal ((S,S) :: OutMon)
      check_reset reset
      integrity_alarm

check_write :: Monad m => ReacT InMon OutMon m ()
check_write = do
  (pw,pi,r) <- signal (C,C) 
  check_reset r
  wait4complete (pw,pi,r)
  where
    wait4complete (_,pi,r) = do
      check_reset r
      case pi of
        Cmp -> return () 
        _   -> do
          i <- signal (C,C)
          wait4complete i
