module MemoryModel where

import Control.Monad.Identity
import Control.Monad.State
import Control.Monad.Resumption.Reactive

data Port a = Val a | DC | Cmp deriving Show

--
-- In the paper, we abbreviate this as (Device i o). (Device i o s) is what's
-- known as a monad transformer, and motivating and explaining its exact structure
-- is described in several previous publications, including:
--   (1) Essence of Multitasking, AMAST 2006, gives a high-level description of
--       the ReacT resumption monad transformer and its application to the semantics
--       of concurrency.
--   (2) Cheap (But Functional) Threads, is a journal length version of (1).
--   (3) Semantics Driven Hardware Design, Implementation, and Verification with ReWire, LCTES15,
--       gives a fuller account of the use of "ReacT i o (StateT s m)" in hardware description.
-- The first author is always willing and eager to discuss this further.
--

type Device i o s m = ReacT i o (StateT s m) ()

type InSig w i = (Port w,Port i)
_datain :: InSig w i -> Port w
_datain (pw,_) = pw
_instr (_,pi)  = pi
_instr  :: InSig w i -> Port i

type OutSig a w e = (Port a,Port a,Port w,Port e)

_fetch, _read :: OutSig a w e -> Port a
_write        :: OutSig a w e -> Port w
_extern       :: OutSig a w e -> Port e

_fetch (oi,da,dw,e)  = oi
_read (oi,da,dw,e)   = da
_write (oi,da,dw,e)  = dw
_extern (oi,da,dw,e) = e

fetch_ oi (_,da,dw,e)  = (oi,da,dw,e)
read_ da (oi,_,dw,e)   = (oi,da,dw,e)
write_ dw (oi,da,_,e)  = (oi,da,dw,e)
extern_ e (oi,da,dw,_) = (oi,da,dw,e)

       ------------------------------------------------------
       --         Asynchronous Read and Write              --
       ------------------------------------------------------

blank :: OutSig a w e
blank = (DC,DC,DC,DC)

async_read :: (Monad m,Show a) => a -> ReacT (Port w,Port i) (Port a,Port a,Port w,Port e) m w
async_read a = do
     i <- signal (readdata a)
     async_wait_read a i
   where
     async_wait_read a i = case _datain i of
       Val w -> return w
       _     -> do
          i <- signal (readdata a)
          async_wait_read a i
     readdata a = (DC,Val a,DC,DC)

async_write :: (Monad m,Show a,Show w) => a -> w -> ReacT (Port w,Port i) (Port a,Port a,Port w,Port e) m ()
async_write a w = do
     i <- signal (writedata a w)
     async_wait_write a w i
   where
     async_wait_write a w i = case _datain i of
       Cmp -> return ()
       _   -> do
          i <- signal (writedata a w)
          async_wait_write a w i
     writedata a w = (DC,Val a,Val w,DC)

       ---------------------------------------------------------
       --            Asynchronous instruction fetch           --
       ---------------------------------------------------------

async_fetch :: (Monad m, Show a) => a -> ReacT (InSig w i) (OutSig a w e) m i
async_fetch a = do
     i <- signal (fetchinstr a)
     async_wait_fetch a i
   where
     async_wait_fetch a i = case _instr i of
       Val w -> return w
       _     -> do
          i <- signal (fetchinstr a)
          async_wait_fetch a i
     fetchinstr a = fetch_ (Val a) blank 

       ---------------------------------------------------------
       --                 RAM and ROM instances               --
       ---------------------------------------------------------

ramsim :: (Eq a, Monad m,Show a,Show w) =>
          (a -> w) -> (Port a, Port w) -> ReacT (Port a, Port w) (Port w) m ()
ramsim sigma (ma,mm) = case (ma,mm) of
  -- Write a m
  (Val a,Val m)  -> do
     signal DC
     signal DC
     signal Cmp
     (ma',mm') <- signal DC
     ramsim (tweek a m sigma) (ma', mm')
         where
           tweek x v m = \ y -> if x==y then v else m y
  -- Read a
  (Val a,_) -> do
     signal DC -- wait a cycle, ignoring input
     signal (Val $ sigma a)
     (ma',mm') <- signal DC
     ramsim sigma (ma', mm')
  (_,_)      -> do
     (ma',mm') <- signal DC
     ramsim sigma (ma', mm')

romsim :: Monad m => (a -> w) -> Port a -> ReacT (Port a) (Port w) m ()
romsim sigma ma = case ma of
  Val a  -> do
    signal DC -- wait a cycle, ignoring input
    signal (Val $ sigma a)
    ma' <- signal DC
    romsim sigma ma'  
  _        -> do
    ma' <- signal DC
    romsim sigma ma'

