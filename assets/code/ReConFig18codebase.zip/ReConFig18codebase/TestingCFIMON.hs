module TestingCFIMON where

import Control.Monad.Identity
import Control.Monad.Resumption.Reactive
import Control.Monad.Resumption.Connectors

import CFG
import CFIMON

type Device i o = ReacT i o Identity ()

good :: Device () (Port Int)
good = do
  signal Enable
  signal DontCare 
  signal DontCare 
  signal (PC 1)
  signal DontCare 
  signal (PC 2)
  signal DontCare 
  signal DontCare 
  signal (PC 3)
  signal DontCare 
  signal (PC 4)
  signal Reset
  signal DontCare

bad :: Device () (Port Int)
bad = do
  signal Enable
  signal DontCare 
  signal DontCare 
  signal (PC 1)
  signal DontCare 
  signal (PC 6)
  signal DontCare 
  signal DontCare 
  signal (PC 3)
  signal DontCare 
  signal (PC 4)
  signal Reset
  signal DontCare

test :: Device () (Port Int)          ->
        Device (Port Int) (Maybe Bit) ->
        [Maybe Bit]
test unittest initial = map snd (unroll (repeat ()) (unittest `pipeline` initial))

unroll :: [i] -> Device i o -> [(i,o)]
unroll [] _               = []
unroll (i:is) (ReacT phi) = case phi of
  Identity (Right (o,k)) -> (i,o) : unroll is (k i)
  Identity (Left _)      -> []

-- Kruft
-- import System.Random

-- ---
-- data Coin = Heads | Tails deriving (Show, Enum, Bounded)

-- instance Random Coin where
--   randomR (a, b) g =
--     case randomR (fromEnum a, fromEnum b) g of
--       (x, g') -> (toEnum x, g')
--   random g = randomR (minBound, maxBound) g

-- main = do
--   g <- newStdGen
--   print . take 10 $ (randoms g :: [Coin])
-- ---
