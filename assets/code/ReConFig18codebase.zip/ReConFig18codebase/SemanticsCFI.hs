module SemanticsCFI where

import Control.Monad.Identity
import Control.Monad.Resumption.Reactive

type Device i o = ReacT i o Identity ()
data Bit        = C | S
data W8         = W8 Bit Bit Bit Bit Bit Bit Bit Bit
type Addr       = Int

data Port a = PC a | DontCare | Enable | Reset deriving Show

predict :: (Addr, Device (Port Addr) (Maybe Bit)) ->
           Device (Port Addr) (Maybe Bit)
predict (i,k) = do
  pa   <- signal (Just C)
  case pa of
   PC a' | a'==i     -> k
         | otherwise -> alarm
   DontCare          -> predict (i,k)
   Enable            -> predict (i,k)
   Reset             -> initial

branch :: (Addr, Device (Port Addr) (Maybe Bit)) ->
          (Addr, Device (Port Addr) (Maybe Bit)) -> 
          Device (Port Addr) (Maybe Bit)
branch (i1,k1) (i2,k2) = do
  pa   <- signal (Just C)
  case pa of
   PC a' | a'==i1    -> k1
         | a'==i2    -> k2
         | otherwise -> alarm
   DontCare          -> branch (i1,k1) (i2,k2)
   Enable            -> branch (i1,k1) (i2,k2)
   Reset             -> initial

stop :: Device (Port Addr) (Maybe Bit) 
stop = initial

k0 :: Device (Port Addr) (Maybe Bit)
k0 = undefined

initial :: Device (Port Addr) (Maybe Bit)
initial = do
   pa <- signal Nothing
   case pa of
     Enable -> begin
     _      -> initial

begin :: Device (Port Addr) (Maybe Bit)
begin = do
   pa   <- signal (Just C)
   case pa of
     PC a' | a'==1     -> k0
           | otherwise -> alarm
     DontCare          -> begin
     Enable            -> begin
     Reset             -> initial

alarm :: Device (Port Addr) (Maybe Bit)
alarm = do
  pa <- signal (Just S)
  case pa of
    Reset -> initial
    _     -> alarm



