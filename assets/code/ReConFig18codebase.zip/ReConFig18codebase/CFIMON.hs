module CFIMON where

import Control.Monad.Identity
import Control.Monad.Resumption.Reactive

data Bit    = C | S deriving Show

data Port a = PC a | DontCare | Enable | Reset deriving Show

initial :: ReacT (Port Int) (Maybe Bit) Identity ()
initial = do
   pa <- signal Nothing
   case pa of
     Enable -> begin
     _      -> initial

begin :: ReacT (Port Int) (Maybe Bit) Identity ()
begin = do
   pa   <- signal (Just C)
   case pa of
     PC a' | a'==1     -> k1
           | otherwise -> alarm
     DontCare          -> begin
     Enable            -> begin
     Reset             -> initial

stop :: ReacT (Port Int) (Maybe Bit) Identity ()
stop = initial

alarm :: ReacT (Port Int) (Maybe Bit) Identity ()
alarm = do
  pa <- signal (Just S)
  case pa of
    Reset -> initial
    _     -> alarm

k1 :: ReacT (Port Int) (Maybe Bit) Identity ()
k1 = do
  pa   <- signal (Just C)
  case pa of
   PC a' | a'==2     -> k2
         | otherwise -> alarm
   DontCare          -> k1
   Enable            -> k1
   Reset             -> initial

k2 :: ReacT (Port Int) (Maybe Bit) Identity ()
k2 = do
  pa   <- signal (Just C)
  case pa of
   PC a' | a'==3     -> k3
         | otherwise -> alarm
   DontCare          -> k2
   Enable            -> k2
   Reset             -> initial

k3 :: ReacT (Port Int) (Maybe Bit) Identity ()
k3 = do
  pa   <- signal (Just C)
  case pa of
   PC a' | a'==4     -> k4
         | otherwise -> alarm
   DontCare          -> k3
   Enable            -> k3
   Reset             -> initial

k4 :: ReacT (Port Int) (Maybe Bit) Identity ()
k4 = do
  pa   <- signal (Just C)
  case pa of
   PC a' | a'==5     -> k5
         | otherwise -> alarm
   DontCare          -> k4
   Enable            -> k4
   Reset             -> initial

k5 :: ReacT (Port Int) (Maybe Bit) Identity ()
k5 = do
  pa   <- signal (Just C)
  case pa of
   PC a' | a'==2     -> k2
         | a'==6     -> k6
         | otherwise -> alarm
   DontCare          -> k5
   Enable            -> k5
   Reset             -> initial

k6 :: ReacT (Port Int) (Maybe Bit) Identity ()
k6 = stop

