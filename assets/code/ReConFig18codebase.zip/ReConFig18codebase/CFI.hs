module CFI where

import CFG

data Kont a = Kont a
data CLA a  = Predict a (Kont a) | Branch (a,Kont a) (a,Kont a) | Stop
data CFL a   = Start a [(Kont a,CLA a)]

prettify []            = "\n"
prettify ((k,cla):eqs) = show k ++ " = " ++ show cla ++ "\n" ++ prettify eqs

cfg2cfl :: CFG a -> CFL a
cfg2cfl (start,cfg) = Start start (map edge2clf cfg)

edge2clf :: Edge a -> (Kont a, CLA a)
edge2clf (a :-> a')      = (Kont a, Predict a' (Kont a'))
edge2clf (a :=> (a1,a2)) = (Kont a, Branch (a1,Kont a1) (a2,Kont a2))
edge2clf (Halt a)        = (Kont a, Stop)

-- ghci> cfg2cfl cfg0
-- init = predict 1 k1
-- k1 = predict 2 k2
-- k2 = predict 3 k3
-- k3 = predict 4 k4
-- k4 = predict 5 k5
-- k5 = branch (2,k2) (6,k6)
-- k6 = stop

-- ghci> cfg2cfl cfg1
-- init = predict 1 k1
-- k1   = predict 2 k2
-- k2   = branch (3,k3) (4,k4)
-- k3   = predict 2 k2
-- k4   = branch (5,k5) (6,k6)
-- k5   = branch (8,k8) (7,k7)
-- k6   = predict 7 k7
-- k7   = predict 11 k11
-- k8   = predict 9 k9
-- k9   = branch (8,k8) (10,k10)
-- k10  = branch (5,k5) (12,k12)
-- k11  = predict 12 k12
-- k12  = stop


instance Show a => Show (Kont a) where
  show (Kont a) = "k" ++ show a

instance Show a => Show (CLA a) where
  show (Predict a k)            = "predict " ++ show a ++ " " ++ show k
  show (Branch (a1,k1) (a2,k2)) = "branch " ++ show (a1,k1) ++ " " ++ show (a2,k2)
  show Stop                     = "stop"

instance Show a => Show (CFL a) where
   show (Start a eqs) = "init = " ++ "predict " ++ show a ++ " " ++ show (Kont a) ++ "\n" ++ prettify eqs

