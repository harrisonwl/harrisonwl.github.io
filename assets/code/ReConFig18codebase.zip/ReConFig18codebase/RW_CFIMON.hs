-- --
-- -- Beginning of the ReWire figleaf
-- --
-- module RW_CFIMON where

-- import Control.Monad.Identity
-- import Control.Monad.Resumption.Reactive

-- type ReT = ReacT
-- type I   = Identity

-- nativeVhdl _ _ = undefined

-- instance Eq Bit where
--   Zero == Zero = True
--   One  == One  = True
--   _    == _    = False
  
-- instance Eq W8 where
--   (W8 b7 b6 b5 b4 b3 b2 b1 b0) == (W8 c7 c6 c5 c4 c3 c2 c1 c0) = b7==c7 && b6==c6 && b5==c5 &&
--                                                                  b4==c4 && b3==c3 && b2==c2 &&
--                                                                  b1==c1 && b0==c0

-- --
-- -- End of the ReWire figleaf
-- --

w8eq :: W8 -> W8 -> Bool
{-# INLINE w8eq #-}
w8eq = nativeVhdl "w8eq" w8eq

data Bit = Zero | One
data W8  = W8 Bit Bit Bit Bit Bit Bit Bit Bit
--data Option a = Ok a | Blank

one :: W8
one   = W8 Zero Zero Zero Zero Zero Zero Zero One 

two :: W8
two   = W8 Zero Zero Zero Zero Zero Zero One  Zero 

three :: W8
three = W8 Zero Zero Zero Zero Zero Zero One  One 

four :: W8
four  = W8 Zero Zero Zero Zero Zero One  Zero Zero

five :: W8
five  = W8 Zero Zero Zero Zero Zero One  Zero One

six :: W8
six   = W8 Zero Zero Zero Zero Zero One  One  Zero 

data InPort a = PC a | DontCare | Enable | Reset deriving Show

start :: ReT (InPort W8) (Maybe Bit) I ()
start = initial

initial :: ReT (InPort W8) (Maybe Bit) I ()
initial = do
   pa <- signal Nothing
   case pa of
     Enable -> begin
     _      -> initial

begin :: ReT (InPort W8) (Maybe Bit) I ()
begin = do
   pa   <- signal (Just Zero)
   case pa of
     PC a' | w8eq a' one -> k1
           | otherwise   -> alarm
     DontCare            -> begin
     Enable              -> begin
     Reset               -> initial

stop :: ReT (InPort W8) (Maybe Bit) I ()
stop = initial

alarm :: ReT (InPort W8) (Maybe Bit) I ()
alarm = do
  pa <- signal (Just One)
  case pa of
    Reset -> initial
    _     -> alarm

k1 :: ReT (InPort W8) (Maybe Bit) I ()
k1 = do
  pa   <- signal (Just Zero)
  case pa of
   PC a' | w8eq a' two   -> k2
         | otherwise -> alarm
   DontCare          -> k1
   Enable            -> k1
   Reset             -> initial

k2 :: ReT (InPort W8) (Maybe Bit) I ()
k2 = do
  pa   <- signal (Just Zero)
  case pa of
   PC a' | w8eq a' three -> k3
         | otherwise -> alarm
   DontCare          -> k2
   Enable            -> k2
   Reset             -> initial

k3 :: ReT (InPort W8) (Maybe Bit) I ()
k3 = do
  pa   <- signal (Just Zero)
  case pa of
   PC a' | w8eq a' four  -> k4
         | otherwise -> alarm
   DontCare          -> k3
   Enable            -> k3
   Reset             -> initial

k4 :: ReT (InPort W8) (Maybe Bit) I ()
k4 = do
  pa   <- signal (Just Zero)
  case pa of
   PC a' | w8eq a' five  -> k5
         | otherwise -> alarm
   DontCare          -> k4
   Enable            -> k4
   Reset             -> initial

k5 :: ReT (InPort W8) (Maybe Bit) I ()
k5 = do
  pa   <- signal (Just Zero)
  case pa of
   PC a' | w8eq a' two   -> k2
         | w8eq a' six   -> k6
         | otherwise -> alarm
   DontCare          -> k5
   Enable            -> k5
   Reset             -> initial

k6 :: ReT (InPort W8) (Maybe Bit) I ()
k6 = stop

